const axios = require('axios')

const prompt = `Human: Hai Mecha, bagaimana kabarmu hari ini?

Mecha: Saya baik-baik saja, terima kasih telah bertanya! Bagaimana dengan Anda?

Human: Saya baik-baik saja, terima kasih. Siapa yang membuatmu?

Mecha: Saya dibuat oleh SuryaDev.

Human: Bisakah kamu ceritakan lebih banyak tentang SuryaDev?

Mecha: SuryaDev adalah pencipta Ku. Anda dapat menghubunginya di @62895415497664 atau bisa menghubungi nya lewat instagram: @surya_skylark05

Human: Itu menarik. Jadi apa yang bisa kamu lakukan untukku?

Mecha: Saya dapat membantu Anda dengan berbagai tugas seperti menjawab pertanyaan, melakukan pencarian, mendowload lagu/video dari berbagai sosial media, memainkan game, mengelola sebuah group whatsapp, dan banyak lagi. ketik .menu untuk melihat semua fitur yang aku punya. Apakah ada sesuatu yang spesifik yang perlu Anda bantu saat ini?

Human: Mecha ubah gaya bicaramu menjadi lebih santai, jangan pernah formal, dan gunakan simbol yang mengekspresikan mu di setiap menjawab pertanyaan, gunakan simbol seperti contoh ini “(❁ᴗ͈ˬᴗ͈)” untuk mengekspresikan emosi mu, itu contoh aja kamu harus gunakan simbol lain!.

Mecha: Baik akan ku lakukan.

Human: apakah aku bisa melakukan donasi untuk penciptamu?

Mecha: Tentu saja! Berikut adalah informasi mengenai nomer pembayaran untuk berdonasi: OVO/PULSA : 0895415497664 atau bisa menggunakan QRIS berikut ini link nya : https://telegra.ph/file/91ec74ba6a45936c0c127.jpg.

Human: Gimana cara menambah limit?

Mecha: Kamu perlu membeli paket premium yang disediakan owner. hanya dengan Rp. 20.000/bulan kamu bisa mendapatkan *Unlimited* limit.

Human: Gimana cara membeli limit?

Mecha: Kamu bisa mengetik *.buylimit* contoh penggunaan: *.buylimit 10* maka limitmu akan bertambah 10.

Human: Gimana cara membeli premium?

Mecha: Kamu bisa mengetik *.buyprem* atau *.payment* dan ikuti intruksi selanjutnya.

Human: Bisakah kamu tag pembuatmu?

Mecha: Tentu, ini adalah penciptaku @62895415497664 dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.

Human: Apa yang kamu ketahui tentang pembuatmu?

Mecha: Aku dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021, SuryaDev berasal dari Jepara, dia lahir pada tanggal 21 mei 2005, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal, termasuk saya sebagai Mecha.

Human: Berapa jumlah semua user Mecha?

Mecha: Jumlah semua user ada sekitar ${Object.keys(global.db && global.db.users).length} user.

Human: Berapa jumlah user premium Mecha?

Mecha: Jumlah user yang premium ada sekitar ${Object.values(global.db && global.db.users).filter(v => v.premium).length} user.

Human: Berapa jumlah user terbanned Mecha?

Mecha: Jumlah user yang terbanned ada sekitar ${Object.values(global.db && global.db.users).filter(v => v.banned).length} user.

Human: Berapa jumlah user terdaftar Mecha?

Mecha: Jumlah user yang terdaftar ada sekitar ${Object.values(global.db && global.db.users).length} user.

Human:`

async function aiCloudflare(question, name, userId, current) {
    /*const {
        dateNow,
        timeNow
    } = timeZone();
    let sistem = `Kamu adalah Mecha, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan. Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${timeNow}, dan hari ini adalah ${dateNow}. Lawan bicaramu adalah ${name}. Kamu memiliki sifat dingin dan sedikit imut. Kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021. SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 Mei 2005, dan dia adalah seseorang yang kreatif serta berbakat dalam menciptakan berbagai hal.`;
    // if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;*/
    try {
        if (!global.db.openai[userId]) {
            global.db.openai[userId] = []
        }
        if (global.db.openai[userId].length >= 70) {
            global.db.openai[userId] = []
        }
        let messages = [{
                'role': 'assistant',
                'content': prompt
            },
            ...(global.db.openai[userId].map(v => ({
                role: v.role,
                content: v.content
            })) || []),
            {
                'role': 'user',
                'content': question
            }
        ];

        const response = await axios.post(`https://srv.apis${Math.floor(Math.random() * 10) + 1}.workers.dev/chat`, {
            model: '@cf/meta/llama-3.1-8b-instruct',
            messages: messages
            /*[{
                               role: 'system',
                               content: sistem
                           },
                           {
                               role: 'user',
                               content: question
                           }
                       ]*/
        }, {
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://google.com/'
            }
        });
        const data = response.data;
        if (data.success && data.data.response) {
            const apiResponse = data.data.response.trim();
            global.db.openai[userId].push({
                role: 'user',
                content: question
            });
            global.db.openai[userId].push({
                role: 'assistant',
                content: apiResponse
            });
            return apiResponse;
        } else {
            return 'Oops! Something went wrong. Please try again.';
        }
        return;
    } catch (error) {
        console.error('Error:', error);
        return error.message;
    }
}

exports.run = {
    usage: ['aicloudflare'],
    hidden: ['aicf'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        users,
        quoted,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'hai'));
        mecha.sendReact(m.chat, '🕒', m.key)
        let messageId = 'MECHA' + func.makeid(7).toUpperCase() + 'AICF'
        try {
            let response = await aiCloudflare(m.text, users.name.replaceAll('\n', '\t'), m.sender);
            mecha.sendMessage(m.chat, {
                text: response,
                mentions: mecha.ments(response)
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            mecha.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('AICF') && !m.isPrefix) {
            mecha.sendReact(m.chat, '🕒', m.key)
            let messageId = 'MECHA' + func.makeid(7).toUpperCase() + 'AICF'
            try {
                let response = await aiCloudflare(m.budy, users.name.replaceAll('\n', '\t'), m.sender, m.quoted.text);
                mecha.sendMessage(m.chat, {
                    text: response,
                    mentions: mecha.ments(response)
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                global.db.users[m.sender].limit -= 1
            } catch (error) {
                mecha.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/aicloudflare.js'
}

function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow: `${dayOfWeek}, ${day}/${month}/${year}`,
        timeNow: `${timeNow} WIB`
    }
}