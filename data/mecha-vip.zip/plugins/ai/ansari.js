const axios = require('axios');

const systemMessage = {
role: "system",
content: "Anda adalah asisten AI yang membantu dalam bahasa Indonesia. Berikan jawaban yang sopan, informatif, dan akurat. Jika Anda tidak yakin tentang sesuatu, katakan saja Anda tidak tahu. Jangan memberikan informasi yang salah atau menyesatkan."
};
const apiRequest = async (messages) => {
const response = await axios.post("https://api.ansari.chat/api/v1/complete", {
messages: [systemMessage, ...messages]
}, {
headers: {
contentType: "application/json",
origin: "https://ansari.chat",
referer: "https://ansari.chat/"
}
});
return response.data;
};

exports.run = {
usage: ['ansari'],
use: 'question',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'pacaran menurut islam'))
await mecha.sendReact(m.chat, '🕒', m.key);
const responseText = await apiRequest([{ role: 'user', content: m.text }]);
mecha.reply(m.chat, responseText, m, {
expiration: m.expiration
})
.then(async () => await mecha.sendReact(m.chat, '✅', m.key))
},
limit: true
}