const axios = require("axios");
const baseurl = "https://bard.rizzy.eu.org";

const Bardie = {
question: async ({ ask }) => {
if (!ask) {
throw new Error("Please specify a question!");
}
try {
const response = await axios.post(`${baseurl}/api/onstage`, { ask }, {
headers: {
"Content-Type": "application/json",
},
});
return response.data;
} catch (err) {
throw new Error("Error: " + err.message);
}
},
image: async ({ ask, image }) => {
if (!ask) {
throw new Error("Please specify a question!");
}
if (!image) {
throw new Error("Please specify a URL for the image!");
}
try {
const response = await axios.post(`${baseurl}/api/onstage/image`, { ask, image }, {
headers: {
"Content-Type": "application/json",
},
});
return response.data;
} catch (err) {
throw new Error("Error: " + err.message);
}
}
}

async function GoogleBard(query) {
return Bardie.question({ ask: query })
};

async function GoogleBardImg(query, url) {
return Bardie.image({ ask: query, image: url })
};

exports.run = {
usage: ['bardie'],
use: 'text',
category: 'ai',
async: async (m, { func, mecha, quoted }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'cara menikmati kelamin'))
let { key } = await mecha.sendMessage(m.chat, {text: '```Sedang mencari jawaban...```'}, {quoted: m, ephemeralExpiration: m.expiration})
if (!quoted.mime) {
let res = await GoogleBard(m.text)
await mecha.sendMessage(m.chat, { text: `${res.content}`, edit: key })
} else {
if (/image\/(png|jpe?g)/.test(quoted.mime)) {
let media = await mecha.downloadAndSaveMediaMessage(m)
let anu = await func.UploadFileUgu(media);
let res = await GoogleBardImg(m.text, anu.url)
await await mecha.sendMessage(m.chat, { text: `${res.content}`, edit: key })
}
}
},
premium: true
}