const {
    proto,
    generateWAMessageFromContent,
    generateWAMessageContent,
    prepareWAMessageMedia
} = require('@whiskeysockets/baileys');
const cheerio = require('cheerio');
const axios = require('axios');

async function bingSearch(query) {
    return axios.get(`https://www.bing.com/images/search?q=${query}`, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36",
        },
    }).then(function({
        data
    }) {
        let $ = cheerio.load(data)
        const result = []
        $(".iuscp").each((i, el) => {
            let img = $(el).find(".img_cont > img").attr("data-src")
            if (!img) return
            result.push({
                title: $(el).find(".b_dataList > li > a").text(),
                images: img,
                source: {
                    name: $(el).find(".lnkw > a").attr("title").split(".")[0].toUpperCase(),
                    url: $(el).find(".lnkw > a").attr("href")
                }
            });
        });
        return result
    });
}

exports.run = {
    usage: ['bingimg'],
    use: 'prompt',
    category: 'ai',
    async: async (m, {
        func,
        mecha
    }) => {
        let text;
        if (m.args.length >= 1) {
            text = m.args.slice(0).join(" ");
        } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
        } else {
            return m.reply(func.example(m.cmd, '1girl'))
        }

        mecha.sendReact(m.chat, '🕒', m.key)
        try {
            const data = await bingSearch(text);
            let result = data.splice(0, 10); // Mengambil 10 gambar pertama dari array yang sudah diacak
            let cards = []
            if (result.length > 0) {
                for (let [index, item] of result.entries()) {
                    try {
                        // if (item.images.endsWith('.svg')) continue
                        cards.push({
                            header: {
                                hasMediaAttachment: true,
                                ...(await prepareWAMessageMedia({
                                    image: {
                                        url: item.images
                                    }
                                }, {
                                    upload: mecha.waUploadToServer
                                }))
                            },
                            body: {
                                text: `${result.length > 1 ? `${item.title} *(${index + 1}/${result.length})*` : global.mess.ok}`
                            },
                            nativeFlowMessage: {
                                buttons: [{
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: 'Source Url',
                                        url: item.source.url
                                    })
                                }],
                            },
                        })
                    } catch (error) {
                        console.error(`Error sending file: ${error.message}`);
                        await m.reply(`Failed to send image *(${index + 1}/${result.length})*`);
                    }
                }

                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: {
                                footer: {
                                    text: `Prompt: ${text}`
                                },
                                carouselMessage: {
                                    cards: cards,
                                    messageVersion: 1,
                                },
                            },
                        },
                    },
                }, {})

                await mecha.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id,
                })
            } else {
                await m.reply("No images found.");
            }
        } catch (error) {
            console.error(`Error in handler: ${error.message}`);
            await m.reply(`${error}\n\n${error.message}`);
        }
    },
    premium: true
}