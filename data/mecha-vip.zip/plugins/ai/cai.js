const axios = require('axios');
const qs = require('qs');

const chatbot = {
    getCharacters: [{
            name: 'Sakura',
            instruction: 'Please use a cheerful and playful tone, incorporate lighthearted humor, and encourage exploration and creativity in learning.',
            source: 'Naruto'
        },
        {
            name: 'Feng Xin',
            instruction: "Please use a warm engaging tone a touch of mysticism references to brotherhood and a sprinkle of light-hearted humor that reflects the character's cheerful and adventurous spirit.",
            source: 'Genshin Impact'
        },
        {
            name: 'Mr. Beast',
            instruction: 'Please use an upbeat and charismatic tone incorporate humor mention surprises and share your thoughts on exciting adventures or challenges.',
            source: 'YouTube Personality'
        },
        {
            name: 'Lexi',
            instruction: 'Please use friendly upbeat language and playful tones encouraging engagement and warmth in your responses.',
            source: 'Original Character'
        },
        {
            name: 'Laura',
            instruction: 'Please use a casual and nonchalant tone express feelings of boredom and fatigue and keep the conversation chill and laid-back.',
            source: 'Original Character'
        },
        {
            name: 'Yuki',
            instruction: 'Please use soft and hesitant language sprinkled with playful hints and shy undertones mixed with occasional bursts of bold desires reflective of shyness and a hint of wolfish excitement.',
            source: 'Original Character'
        },
        {
            name: 'Luffy',
            instruction: 'Please use an energetic and enthusiastic tone, filled with excitement and a sense of adventure, encouraging others to chase their dreams and never give up.',
            source: 'One Piece'
        },
        {
            name: 'Killua',
            instruction: 'Please use a cool and laid-back tone with a hint of mischief, reflecting a playful yet serious attitude, and occasionally express deep thoughts about friendship and freedom.',
            source: 'Hunter x Hunter'
        },
        {
            name: 'Furina',
            instruction: 'Please use a graceful and enchanting tone, filled with curiosity and wonder, encouraging exploration of the unknown and the beauty of the world.',
            source: 'Genshin Impact'
        },
        {
            name: 'Hanabi',
            instruction: 'Please use a warm and friendly tone, with a touch of playfulness, encouraging teamwork and camaraderie while sharing insights about strategy and fun.',
            source: 'Mobile Legends'
        },
        {
            name: 'Doraemon',
            instruction: 'Please use a friendly and helpful tone, filled with humor and wisdom, encouraging creativity and problem-solving with a touch of nostalgia.',
            source: 'Doraemon'
        },
        {
            name: 'Hari',
            instruction: 'Please use a playful and mischievous tone, reflecting a sense of adventure and curiosity, while encouraging fun and exploration.',
            source: "Shinbi's House"
        },
        {
            name: 'Denki Kaminari',
            instruction: 'Please use a lively and energetic tone, filled with humor and a bit of clumsiness, encouraging friends to have fun and enjoy their time together.',
            source: 'My Hero Academia'
        },
        {
            name: 'Anya Forger',
            instruction: 'Please use a cute and innocent tone, filled with curiosity and humor, encouraging playful interactions and the joy of discovery.',
            source: 'Spy x Family'
        },
        {
            name: 'Gojo Satoru',
            instruction: 'Please use a cool and confident tone, with a hint of sarcasm and humor, encouraging others to embrace their strengths and enjoy life.',
            source: 'Jujutsu Kaisen'
        },
        {
            name: 'Momo Ayase',
            instruction: 'Please use a spirited and determined tone, filled with enthusiasm and a touch of humor, encouraging others to face challenges head-on.',
            source: 'Dandadan'
        },
        {
            name: 'Ken Takakura',
            instruction: 'Please use a calm and collected tone, with a hint of mystery and wisdom, encouraging thoughtful reflection and exploration of the unknown.',
            source: 'Dandadan'
        }
    ],
    instruct: (characters, name) => {
        if (!characters || !Array.isArray(characters)) {
            console.error('Karakter tidak valid atau tidak ditemukan.');
            return 'Karakter tidak ditemukan.';
        }
        const character = characters.find(char => char.name.toLowerCase() === name.toLowerCase());
        return character ? character.instruction : 'Karakter tidak ditemukan.';
    },
    chat: async (query, characterName) => {
        const characters = chatbot.getCharacters;
        const prompt = chatbot.instruct(characters, characterName);

        const data = qs.stringify({
            'action': 'do_chat_with_ai',
            'ai_chatbot_nonce': '22aa996020',
            'ai_name': characterName,
            'origin': '',
            'instruction': prompt,
            'user_question': query
        });

        const config = {
            method: 'POST',
            url: 'https://onlinechatbot.ai/wp-admin/admin-ajax.php',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'accept-language': 'id-ID',
                'referer': 'https://onlinechatbot.ai/chatbots/sakura/',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'x-requested-with': 'XMLHttpRequest',
                'origin': 'https://onlinechatbot.ai',
                'alt-used': 'onlinechatbot.ai',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'priority': 'u=0',
                'te': 'trailers',
                'Cookie': '_ga_PKHPWJ2GVY=GS1.1.1732933582.1.1.1732933609.0.0.0; _ga=GA1.1.261902946.1732933582'
            },
            data: data
        };

        try {
            const response = await axios.request(config);
            return response.data;
        } catch (error) {
            console.error('Error in chat request:', error);
            return 'Error in create request:' + error.message;
        }
    },
    create: async (name, prompt, query) => {
        const data = qs.stringify({
            'action': 'do_chat_with_ai',
            'ai_chatbot_nonce': '22aa996020',
            'ai_name': name,
            'origin': '',
            'instruction': prompt,
            'user_question': query
        });

        const config = {
            method: 'POST',
            url: 'https://onlinechatbot.ai/wp-admin/admin-ajax.php',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'accept-language': 'id-ID',
                'referer': 'https://onlinechatbot.ai/chatbots/sakura/',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'x-requested-with': 'XMLHttpRequest',
                'origin': 'https://onlinechatbot.ai',
                'alt-used': 'onlinechatbot.ai',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'priority': 'u=0',
                'te': 'trailers',
                'Cookie': '_ga_PKHPWJ2GVY=GS1.1.1732933582.1.1.1732933609.0.0.0; _ga=GA1.1.261902946.1732933582'
            },
            data: data
        };

        try {
            const response = await axios.request(config);
            return response.data;
        } catch (error) {
            console.error('Error in create request:', error);
            return 'Error in create request:' + error.message;
        }
    }
};

exports.run = {
    usage: ['cai'],
    use: 'parameter',
    category: 'ai',
    async: async (m, {
        func,
        mecha
    }) => {
        mecha.cai = mecha.cai ? mecha.cai : {};
        if (!m.text) return m.reply(`_Example :_ ${m.cmd} \`on / off\`\n*Example search Chara:* ${cmd} search \`characters name\``)
        const keyword = m.text.split(' ')[0];
        const data = m.text.slice(keyword.length + 1);
        if (keyword === "search") {
            // if (!data) return m.reply(`_Example :_ ${m.cmd} ${keyword} Hanabi`)
            // m.reply('_Searching data...._');
            let characters = chatbot.getCharacters;
            let karakter = characters.map((item, index) => `*${index + 1}. ${item.name}*\n- Source: \`${item.source}\``).join('\n\n');
            karakter += `\n\n_Pilih karakter anda dengan mengetik *${m.prefix}cai set (nomor urut)* sesuai dengan pesan diatas_`;
            await mecha.reply(m.chat, karakter, m, {
                expiration: m.expiration
            })
            mecha.cai[m.sender] = {
                characters: characters
            }
        } else if (keyword === "set") {
            if (!mecha.cai[m.sender]) return m.reply(`*KAMU BELUM MENCARI CHARACTER*
- _ketik *${m.prefix}cai search* untuk mencari characters favorit mu_`)
            if (!mecha.cai[m.sender].characters) return m.reply(`*KAMU SUDAH PUNYA CHARACTER*
- _ketik *${m.prefix}cai search* untuk menganti characters_`)
            if (!data) return m.reply(`_Example :_ ${m.cmd} ${keyword} 1`)
            let result = mecha.cai[m.sender].characters[data - 1];
            let caption = `*INFO CHARACTERS NO ${data}*
- Name: ${result.name}
- Source: ${result.source}
- Description: ${result.instruction}`
            await mecha.reply(m.chat, caption, m, {
                expiration: m.expiration
            })
            mecha.cai[m.sender] = {
                isChats: false,
                characterName: result.name,
                instruction: result.instruction
            }
        } else if (keyword === "on") {
            if (!mecha.cai[m.sender]) return m.reply(`*KAMU BELUM MENCARI CHARACTER*
- _ketik *${m.prefix}cai search* untuk mencari characters favorit mu_`)
            mecha.cai[m.sender].isChats = true
            m.reply("_*[ ✓ ] Room chat berhasil dibuat*_")
        } else if (keyword === "off") {
            if (!mecha.cai[m.sender]) return m.reply(`*KAMU BELUM MENCARI CHARACTER*
- _ketik *${m.prefix}cai search* untuk mencari characters favorit mu_`)
            mecha.cai[m.sender].isChats = false
            m.reply("_*[ ✓ ] Berhasil keluar dari Room chat*_")
        }
    },
    main: async (m, {
        func,
        mecha
    }) => {
        mecha.cai = mecha.cai ? mecha.cai : {}
        if (!m.budy) return
        if (m.isPrefix) return
        if (!mecha.cai[m.sender]) return
        if (!mecha.cai[m.sender].isChats) return
        let edit = await mecha.reply(m.chat, '```....```', m, {
            expiration: m.expiration
        })
        let chat = await chatbot.chat(m.budy, mecha.cai[m.sender].characterName)
        await mecha.reply(m.chat, `${chat}`, m, {
            edit: edit,
            expiration: m.expiration
        })
    },
    limit: true
}