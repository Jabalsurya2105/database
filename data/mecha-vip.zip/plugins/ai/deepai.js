const userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36";

function generateRandomHash() {
    var randomValue = Math.round((Math.random() * 100000000000)) + "";
    var hashFunction = function() {
        for (var sineValues = [], index = 0; 64 > index;)
            sineValues[index] = 0 | 4294967296 * Math.sin(++index % Math.PI);
        return function(inputString) {
            var p, h, i, a = [p = 1732584193, h = 4023233417, ~p, ~h],
                hashValues = [],
                encodedString = unescape(encodeURI(inputString)) + "\u0080",
                length = encodedString.length;
            inputString = --length / 4 + 2 | 15;
            for (hashValues[--inputString] = 8 * length; ~length;)
                hashValues[length >> 2] |= encodedString.charCodeAt(length) << 8 * length--;
            for (index = encodedString = 0; index < inputString; index += 16) {
                for (length = a; 64 > encodedString; length = [i = length[3], p + ((i = length[0] + [p & h | ~p & i, i & p | ~i & h, p ^ h ^ i, h ^ (p | ~i)][length = encodedString >> 4] + sineValues[encodedString] + ~~hashValues[index | [encodedString, 5 * encodedString + 1, 3 * encodedString + 5, 7 * encodedString][length] & 15]) << (length = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21][4 * length + encodedString++ % 4]) | i >>> -length), p, h])
                    p = length[1] | 0,
                    h = length[2];
                for (encodedString = 4; encodedString;)
                    a[--encodedString] += length[encodedString]
            }
            for (inputString = ""; 32 > encodedString;)
                inputString += (a[encodedString >> 3] >> 4 * (1 ^ encodedString++) & 15).toString(16);
            return inputString.split("").reverse().join("")
        }
    }();
    return 'tryit-' + randomValue + '-' + hashFunction(userAgent + hashFunction(userAgent + hashFunction(userAgent + randomValue + 'suditya_is_a_smelly_hacker')));
}

const DeepAI = {
    async image(prompt) {
        const body = `------WebKitFormBoundaryNm9NAbhIVIsN9Vn6\r\nContent-Disposition: form-data; name="text"\r\n\r\n${prompt}\r\n------WebKitFormBoundaryNm9NAbhIVIsN9Vn6\r\nContent-Disposition: form-data; name="image_generator_version"\r\n\r\nhd\r\n------WebKitFormBoundaryNm9NAbhIVIsN9Vn6\r\nContent-Disposition: form-data; name="use_old_model"\r\n\r\nfalse\r\n------WebKitFormBoundaryNm9NAbhIVIsN9Vn6\r\nContent-Disposition: form-data; name="turbo"\r\n\r\ntrue\r\n------WebKitFormBoundaryNm9NAbhIVIsN9Vn6\r\nContent-Disposition: form-data; name="genius_preference"\r\n\r\nclassic\r\n------WebKitFormBoundaryNm9NAbhIVIsN9Vn6--\r\n`;
        return this.execute(body, 'api/text2img')
    },
    async video(prompt) {
        const body = `------WebKitFormBoundaryIgjn20k3Xs6BtvkS\r\nContent-Disposition: form-data; name="textPrompt"\r\n\r\n${prompt}\r\n------WebKitFormBoundaryIgjn20k3Xs6BtvkS\r\nContent-Disposition: form-data; name="dimensions"\r\n\r\n{"width":1024,"height":1024}\r\n------WebKitFormBoundaryIgjn20k3Xs6BtvkS--\r\n`;
        return this.execute(body, 'generate_video')
    },
    async execute(body, endpoint) {
        try {
            const apiKey = generateRandomHash();
            const response = await fetch("https://api.deepai.org/" + endpoint, {
                method: "POST",
                headers: {
                    "accept": "*/*",
                    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                    "api-key": apiKey,
                    "content-type": "multipart/form-data; boundary=----WebKitFormBoundaryNm9NAbhIVIsN9Vn6",
                    "user-agent": userAgent,
                    "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
                    "sec-ch-ua-mobile": "?1",
                    "sec-ch-ua-platform": '"Android"',
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-site",
                    "cookie": "user_sees_ads=false"
                },
                referrerPolicy: "same-origin",
                body: body
            });

            const data = await response.json();
            return data;
        } catch (error) {
            console.error("Error while generating:", error);
            return null;
        }
    }
};

exports.run = {
    usage: ['deepai'],
    use: 'prompt',
    category: 'ai',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'cat running in the grass field'));
        mecha.sendReact(m.chat, '🕒', m.key);
        const prompt = m.text.trim();
        const image = await DeepAI.image(prompt);
        const video = await DeepAI.video(prompt);
        console.log(video);

        const {
            id,
            output_url,
            share_url,
            backend_request_id
        } = image;
        mecha.sendMedia(m.chat, output_url, m, {
            caption: `- ID: ${id}
- Prompt: ${m.text}
- Backend requestId: ${backend_request_id}`,
            expiration: m.expiration
        })
    },
    location: 'plugins/ai/deepai.js'
}