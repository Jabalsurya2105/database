const axios = require('axios');
  
const fluximg = {
  defaultRatio: "2:3", 

  create: async (query) => {
    const config = {
      headers: {
        accept: "*/*",
        authority: "1yjs1yldj7.execute-api.us-east-1.amazonaws.com",
        "user-agent": "Postify/1.0.0",
      },
    };

    try {
      const response = await axios.get(
        `https://1yjs1yldj7.execute-api.us-east-1.amazonaws.com/default/ai_image?prompt=${encodeURIComponent(
          query
        )}&aspect_ratio=${fluximg.defaultRatio}`,
        config
      );
      return {
        imageLink: response.data.image_link,
      };
    } catch (error) {
      console.error(error);
      throw error;
    }
  },
};

exports.run = {
usage: ['flux'],
use: 'prompt',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'a girls'))
mecha.sendReact(m.chat, '🕒', m.key)
const result = await fluximg.create(m.text);
if (result && result.imageLink) {
mecha.sendMedia(m.chat, result.imageLink, m, {
caption: `Hasil Flux:\n\nPrompt: ${m.text}`,
expiration: m.expiration
})
} else m.reply('terjadi kesalahan saat membuat gambar.')
},
premium: true
}