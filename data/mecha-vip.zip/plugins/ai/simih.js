const fetch = require('node-fetch');
const {
    URLSearchParams
} = require('url');

exports.run = {
    usage: ['simi'],
    hidden: ['simih'],
    use: 'question',
    category: 'ai',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
        await mecha.sendReact(m.chat, '🕒', m.key)
        let messageId = 'BAE5' + func.makeid(8).toUpperCase() + 'SIMI'
        try {
            let response = await chatWithSimi(m.text);
            mecha.sendMessage(m.chat, {
                text: `${response}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
            await mecha.sendReact(m.chat, '✅', m.key)
        } catch (e) {
            mecha.sendReact(m.chat, '❌', m.key)
        }
    },
    main: async (m, {
        func,
        mecha
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('SIMI') && !m.isPrefix) {
            await mecha.sendReact(m.chat, '🕒', m.key)
            let messageId = 'BAE5' + func.makeid(8).toUpperCase() + 'SIMI'
            try {
                let response = await chatWithSimi(m.budy);
                mecha.sendMessage(m.chat, {
                    text: `${response}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                global.db.users[m.sender].limit -= 1
                await mecha.sendReact(m.chat, '✅', m.key)
            } catch (e) {
                mecha.sendReact(m.chat, '❌', m.key)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/simih.js'
}

async function chatWithSimi(text, languageCode = 'id') {
    const url = 'https://api.simsimi.vn/v1/simtalk';
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    };

    const data = new URLSearchParams();
    data.append('text', text);
    data.append('lc', languageCode);

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers,
            body: data.toString(),
        });
        const rawResponse = await response.text();
        console.log('Raw Response:', rawResponse);

        // .text() => .json()
        try {
            const jsonResponse = JSON.parse(rawResponse);
            return jsonResponse.message;
        } catch (error) {
            console.error('Respons bukan JSON:', rawResponse);
            throw new Error('Respons dari server bukan JSON yang valid');
        }
    } catch (error) {
        console.error('Error asking SimSimi:', error);
        throw error;
    }
}