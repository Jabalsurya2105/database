exports.run = {
usage: [
'anonymous',
'start',
'next',
'stop',
'sendprofile',
],
hidden: [
'search',
'skip',
'sendprofile',
],
use: '',
category: 'user',
async: async (m, { func, mecha }) => {
this.anonymous = this.anonymous ? this.anonymous : {}
switch (m.command) {
// Anonymous Chat
case 'anonymous':{
let button = [
['button', 'SEARCH', m.prefix+'start']
]
let title = `Hai ${m.pushname !== undefined ? m.pushname : 'Kak'}`
let body = `Selamat Datang di Anonymous Chat\n\nKetik ${m.prefix}search untuk mencari Teman Chat anda, atau bisa pencet tombol Search dibawah`
mecha.sendButton(m.chat, title, body, global.footer, button, m, {
expiration: m.expiration
})
}
break
case 'start': case 'search':{
var rooms = Object.values(this.anonymous).find(room => room.check(m.sender))
if (rooms) {
let button = [
['button', 'STOP', m.prefix+'stop'],
['button', 'SKIP', m.prefix+'skip']
]
var body = `[⚠️] Kamu masih dalam sesi chat dengan partner! ❌`
return mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
}
var roomm = Object.values(this.anonymous).find(room => room.state == "WAITING" && !room.check(m.sender))
if (roomm) {
let button = [
['button', 'STOP', m.prefix+'stop'],
['button', 'SKIP', m.prefix+'skip']
]
roomm.b = m.sender
roomm.state = "CHATTING"
var body = `_Pasangan Ditemukan 🐼_\n${m.prefix}skip -- _cari pasangan baru_\n${m.prefix}stop -- _hentikan dialog ini_`
await mecha.sendButton(roomm.a, '', body, global.footer, button, m, {
expiration: m.expiration
})
await mecha.sendButton(roomm.b, '', body, global.footer, button, m, {
expiration: m.expiration
})
} else if (!rooms) {
let id = + new Date
this.anonymous[id] = {
id,
a: m.sender,
b: '',
state: "WAITING",
check: function(who = '') {
return [this.a, this.b].includes(who)
},
other: function(who = '') {
return who == this.a ? this.b : who == this.b ? this.a : ''
}
}
let button = [
['button', 'STOP', m.prefix+'stop'],
]
var body = `[🔎] Mohon tunggu sedang mencari teman chat`
await mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
}
}
break
case 'next': case 'skip':{
let romeo = Object.values(this.anonymous).find(room => room.check(m.sender))
let button = [
['button', 'SEARCH', m.prefix+'start']
]
if (!romeo) {
var body = `[⚠️] Kamu belum pernah memulai chat! ❌`
await mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
return false
}
let other = romeo.other(m.sender)
var teks1 = `[⚠️] Sesi chat ini telah diberhentikan oleh teman chat kamu! ❌`
if (other) await mecha.sendButton(other, '', teks1, global.footer, button, m, {
expiration: m.expiration
})
delete this.anonymous[romeo.id]
let room = Object.values(this.anonymous).find(room => room.state == "WAITING" && !room.check(m.sender))
if (room) {
let button = [
['button', 'STOP', m.prefix+'stop'],
['button', 'SKIP', m.prefix+'skip']
]
room.b = m.sender
room.state = "CHATTING"
var body = `_Pasangan Ditemukan 🐼_\n${m.prefix}skip -- _cari pasangan baru_\n${m.prefix}stop -- _hentikan dialog ini_`
await mecha.sendButton(room.a, '', body, global.footer, button, m, {
expiration: m.expiration
})
await mecha.sendButton(room.b, '', body, global.footer, button, m, {
expiration: m.expiration
})
} else {
let id = + new Date
this.anonymous[id] = {
id,
a: m.sender,
b: '',
state: "WAITING",
check: function(who = '') {
return [this.a, this.b].includes(who)
},
other: function(who = '') {
return who == this.a ? this.b : who == this.b ? this.a : ''
}
}
let button = [
['button', 'STOP', m.prefix+'stop'],
]
var body = `[🔎] Mohon tunggu sedang mencari teman chat`
await mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
}
}
break
case 'stop':{
var room = Object.values(this.anonymous).find(room => room.check(m.sender))
if (!room) {
let button = [
['button', 'SEARCH', m.prefix+'start']
]
var body = `[⚠️] Kamu belum pernah mulai chat! ❌`
await mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
return false
} else {
let button = [
['button', 'SEARCH', m.prefix+'start']
]
var teks = `[✅] Berhasil memberhentikan chat`
var teks2 = `[⚠️] Sesi chat ini telah diberhentikan oleh teman chat kamu`
await mecha.sendButton(m.chat, '', teks, global.footer, button, m, {
expiration: m.expiration
})
let other = room.other(m.sender)
if (other) await mecha.sendButton(other, '', teks2, global.footer, button, m, {
expiration: m.expiration
})
delete this.anonymous[room.id]
}
}
break
case 'sendprofile': case 'sendprofil':{
let room = Object.values(this.anonymous).find(room => room.check(m.sender))
let button = [
['button', 'SEARCH', m.prefix+'start']
]
if (!room) {
var body = `[⚠️] Kamu belum pernah memulai chat! ❌`
await mecha.sendButton(m.chat, '', body, global.footer, button, m, {
expiration: m.expiration
})
return false
} else {
let rms = Object.values(this.anonymous).find(room => [room.a, room.b].includes(m.sender) && room.state == "CHATTING")
var other = rms.other(m.sender)
var res = await mecha.sendkontak(other, m.sender, m.pushname, m)
mecha.reply(m.chat, '[✅] Berhasil mengirim profil ke teman chat anda!', m, {
expiration: m.expiration
})
mecha.reply(other, '[👨👩] Teman chat kamu memberikan kontak profil nya!', res, {
expiration: m.expiration
})
}
}
break
}
},
main: async (m, { func, mecha }) => {
// Anonymous Chat
if (m.isPc && !m.key.fromMe && !m.isPrefix) {
this.anonymous = this.anonymous ? this.anonymous : {}
let room = Object.values(this.anonymous).find(room => [room.a, room.b].includes(m.sender) && room.state == "CHATTING")
if (room) {
var other = [room.a, room.b].find(user => user !== m.sender)
await mecha.copyNForward(other, m, true, m.quoted && m.quoted.fromMe ? {contextInfo: {...m.msg.contextInfo, participant: other}} : {})
await mecha.sendMessage(m.chat, {react: {text: '📬', key: m.key}})
}
}
},
private: true
}