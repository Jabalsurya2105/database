exports.run = {
usage: ['antisticker'],
hidden: ['antistiker'],
use: 'on / off',
category: 'group',
async: async (m, { func, mecha }) => {
let setting = global.db.groups[m.chat];
if (!setting.hasOwnProperty('antisticker')) {
setting.antisticker = false;
}
if (!m.isDevs || !m.isOwner) return m.reply(global.mess.devs);
if (!m.args || !m.args[0]) return m.reply(`*Current status* : ${setting.antisticker ? 'active' : 'non-active'}\n\n${func.example(m.cmd, 'on / off')}`)
let option = m.args[0].toLowerCase()
let optionList = ['on', 'off'];
if (!optionList.includes(option)) return m.reply(func.example(m.cmd, 'on / off'))
let status = option === 'on' ? true : false;
if (setting.antisticker == status) return m.reply(`${func.ucword(m.command)} has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
setting.antisticker = status;
mecha.reply(m.chat, `${func.ucword('antisticker')} has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`, m, {
expiration: m.expiration
})
},
main: async (m, { func, mecha, groups }) => {
if (!groups.hasOwnProperty('antisticker')) {
groups.antisticker = false;
}
if (groups.antisticker && /stickerMessage/i.test(m.mtype)) return await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
})
},
botAdmin: true,
group: true
}