exports.run = {
usage: ['blowjob'],
hidden: ['bjob'],
use: '',
category: 'nsfw',
async: async (m, { func, mecha, packname, author }) => {
mecha.sendReact(m.chat, '🕒', m.key)
let { key } = await mecha.sendStickerFromUrl(m.chat, 'https://api.arifzyn.tech/dewasa/blowjob?apikey=AR-akvLBLTkQFOI', m, {
packname,
author,
expiration: m.expiration
})
setTimeout(() => {
mecha.sendMessage(m.chat, { delete: key }); 
}, 15 * 1000)
},
premium: true
}