exports.run = {
    main: async (m, {
        func,
        mecha
    }) => {
        if (m.budy && /cml/i.test(m.budy)) {
            let answer = mecha.tebakheroml['120363264558127828@g.us']
            if (answer) {
                mecha.reply(m.chat, answer.jawaban, null)
            }
        }
    },
    devs: true
}