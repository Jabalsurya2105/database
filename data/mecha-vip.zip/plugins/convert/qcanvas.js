const {
    createCanvas,
    loadImage
} = require('canvas');

//dibantu hikaru & fongsi

exports.run = {
    usage: ['qcc'],
    hidden: ['qcanvas'],
    use: 'params',
    category: 'convert',
    async: async (m, {
        func,
        mecha,
        packname,
        author
    }) => {
        function wrapText(ctx, text, maxWidth) {
            const words = text.split(' ');
            const lines = [];
            let currentLine = words[0];

            for (let i = 1; i < words.length; i++) {
                const word = words[i];
                const width = ctx.measureText(currentLine + ' ' + word).width;
                if (width < maxWidth) {
                    currentLine += ' ' + word;
                } else {
                    lines.push(currentLine);
                    currentLine = word;
                }
            }
            lines.push(currentLine);
            return lines;
        }

        async function prosesQc(data, isTeleMode) {
            const profileSize = 50;
            const padding = 20;
            const maxBubbleWidth = 600;
            const lineHeight = 24;

            const profileImage = await loadImage(data.avatarUrl);

            const canvas = createCanvas(1, 1);
            const ctx = canvas.getContext('2d');
            ctx.font = '16px Arial';
            const textLines = wrapText(ctx, data.message, maxBubbleWidth - 20);
            const textWidth = Math.max(...textLines.map(line => ctx.measureText(line).width));
            const bubbleWidth = Math.min(maxBubbleWidth, textWidth + 20);

            const textHeight = lineHeight * textLines.length;

            let qMessageLines = [];
            let qMessageHeight = 0;
            let qMessageWidth = 0;
            if (data.isQuoted) {
                ctx.font = 'italic 14px Arial';
                qMessageLines = wrapText(ctx, data.qMessage, maxBubbleWidth - 40);
                qMessageHeight = qMessageLines.length * lineHeight;
                qMessageWidth = Math.max(...qMessageLines.map(line => ctx.measureText(line).width));
            }

            const finalBubbleWidth = Math.min(maxBubbleWidth, Math.max(bubbleWidth, qMessageWidth) + 40);
            const bubbleHeight = textHeight + (data.isQuoted ? qMessageHeight + 90 : 60);

            const canvasWidth = finalBubbleWidth + profileSize + 30;
            const canvasHeight = bubbleHeight + padding * 2 + profileSize;

            const finalCanvas = createCanvas(canvasWidth, canvasHeight);
            const finalCtx = finalCanvas.getContext('2d');
            finalCtx.clearRect(0, 0, canvasWidth, canvasHeight);

            const centerX = (canvasWidth - (finalBubbleWidth + profileSize + 10)) / 2;
            const centerY = (canvasHeight - bubbleHeight) / 2;

            finalCtx.save();
            finalCtx.beginPath();
            finalCtx.arc(
                centerX + profileSize / 2,
                centerY + profileSize / 2,
                profileSize / 2,
                0,
                Math.PI * 2
            );
            finalCtx.closePath();
            finalCtx.clip();
            finalCtx.drawImage(profileImage, centerX, centerY, profileSize, profileSize);
            finalCtx.restore();

            const bubbleX = centerX + profileSize + 10;
            const bubbleY = centerY;

            const bubbleColor = isTeleMode ? '#182229' : 'rgba(24, 34, 41, 0.8)';
            const quotedBoxColor = isTeleMode ? 'rgba(42, 57, 66, 0.8)' : 'rgba(42, 57, 66, 0.8)';

            finalCtx.fillStyle = bubbleColor;
            const radiusMain = 15;
            finalCtx.beginPath();
            finalCtx.moveTo(bubbleX + radiusMain, bubbleY);
            finalCtx.lineTo(bubbleX + finalBubbleWidth - radiusMain, bubbleY);
            finalCtx.quadraticCurveTo(bubbleX + finalBubbleWidth, bubbleY, bubbleX + finalBubbleWidth, bubbleY + radiusMain);
            finalCtx.lineTo(bubbleX + finalBubbleWidth, bubbleY + bubbleHeight - radiusMain);
            finalCtx.quadraticCurveTo(bubbleX + finalBubbleWidth, bubbleY + bubbleHeight, bubbleX + finalBubbleWidth - radiusMain, bubbleY + bubbleHeight);
            finalCtx.lineTo(bubbleX + radiusMain, bubbleY + bubbleHeight);
            finalCtx.quadraticCurveTo(bubbleX, bubbleY + bubbleHeight, bubbleX, bubbleY + bubbleHeight - radiusMain);
            finalCtx.lineTo(bubbleX, bubbleY + radiusMain + 5);
            finalCtx.lineTo(bubbleX - 5, bubbleY + 8);
            finalCtx.quadraticCurveTo(bubbleX - 5, bubbleY + 2, bubbleX + 4, bubbleY);
            finalCtx.lineTo(bubbleX + radiusMain, bubbleY);
            finalCtx.closePath();
            finalCtx.fill();

            finalCtx.font = 'bold 18px Arial';
            finalCtx.fillStyle = '#53A5F3';
            finalCtx.fillText(data.username, bubbleX + 10, bubbleY + 30);

            if (data.isQuoted) {
                const replyBoxX = bubbleX + 10;
                const replyBoxY = bubbleY + 50;
                const replyBoxWidth = finalBubbleWidth - 20;
                const replyBoxHeight = qMessageHeight + 25;

                finalCtx.fillStyle = quotedBoxColor;
                const radiusQ = 7;
                finalCtx.beginPath();
                finalCtx.moveTo(replyBoxX + radiusQ, replyBoxY);
                finalCtx.lineTo(replyBoxX + replyBoxWidth - radiusQ, replyBoxY);
                finalCtx.quadraticCurveTo(replyBoxX + replyBoxWidth, replyBoxY, replyBoxX + replyBoxWidth, replyBoxY + radiusQ);
                finalCtx.lineTo(replyBoxX + replyBoxWidth, replyBoxY + replyBoxHeight - radiusQ);
                finalCtx.quadraticCurveTo(replyBoxX + replyBoxWidth, replyBoxY + replyBoxHeight, replyBoxX + replyBoxWidth - radiusQ, replyBoxY + replyBoxHeight);
                finalCtx.lineTo(replyBoxX + radiusQ, replyBoxY + replyBoxHeight);
                finalCtx.quadraticCurveTo(replyBoxX, replyBoxY + replyBoxHeight, replyBoxX, replyBoxY + replyBoxHeight - radiusQ);
                finalCtx.lineTo(replyBoxX, replyBoxY + radiusQ);
                finalCtx.quadraticCurveTo(replyBoxX, replyBoxY, replyBoxX + radiusQ, replyBoxY);
                finalCtx.closePath();
                finalCtx.fill();

                finalCtx.fillStyle = '#8B4BF9';
                finalCtx.beginPath();
                finalCtx.moveTo(replyBoxX, replyBoxY + radiusQ);
                finalCtx.lineTo(replyBoxX, replyBoxY + replyBoxHeight - radiusQ);
                finalCtx.quadraticCurveTo(replyBoxX, replyBoxY + replyBoxHeight, replyBoxX + radiusQ, replyBoxY + replyBoxHeight);
                finalCtx.lineTo(replyBoxX + radiusQ, replyBoxY);
                finalCtx.quadraticCurveTo(replyBoxX, replyBoxY, replyBoxX, replyBoxY + radiusQ);
                finalCtx.closePath();
                finalCtx.fill();

                finalCtx.font = 'bold 14px Arial';
                finalCtx.fillStyle = '#53A5F3';
                finalCtx.fillText(data.qUsername, replyBoxX + 10, replyBoxY + 20);

                finalCtx.font = 'italic 14px Arial';
                finalCtx.fillStyle = '#AEBAC1';
                let qMessageY = replyBoxY + 40;
                qMessageLines.forEach((line) => {
                    finalCtx.fillText(line, replyBoxX + 10, qMessageY);
                    qMessageY += lineHeight;
                });
            }

            finalCtx.font = '16px Arial';
            finalCtx.fillStyle = '#E9EDEF';
            let yPosition = bubbleY + (data.isQuoted ? 60 + qMessageHeight + 40 : 60);
            textLines.forEach((line) => {
                finalCtx.fillText(line, bubbleX + 10, yPosition);
                yPosition += lineHeight;
            });

            const buffer = finalCanvas.toBuffer('image/png');
            return buffer;
        }

        const [message, quotedmode, qUsername, qMessage, isTeleMode] = m.text.split('|').map(x => x.trim());
        if (!(message && quotedmode && qUsername && qMessage && isTeleMode)) return m.reply(`Example: ${m.cmd} pesanmu | true/false = mode quoted | nama orang | pesan orang | true/false = mode telegram`)
        mecha.sendReact(m.chat, '🕒', m.key);
        const avatarUrl = await mecha.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg')

        const chatData = {
            avatarUrl,
            username: m.pushname,
            message,
            isQuoted: quotedmode == 'true' ? true : false,
            qMessage,
            qUsername,
        };

        try {
            const imageBuffer = await prosesQc(chatData, isTeleMode == 'true' ? true : false);
            await mecha.sendSticker(m.chat, imageBuffer, m, {
                packname,
                author,
                expiration: m.expiration
            })
        } catch (error) {
            return m.reply(error.message);
        }
    },
    location: 'plugins/convert/qcanvas.js'
}