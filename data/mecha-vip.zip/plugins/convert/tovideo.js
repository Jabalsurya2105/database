const cheerio = require('cheerio');
const FormData = require('form-data');
const fetch = require('node-fetch');

async function webp2mp4(source) {
try {
let form = new FormData();
let isUrl = typeof source === "string" && /https?:\/\//.test(source);
form.append("new-image-url", isUrl ? source : "");
form.append("new-image", isUrl ? "" : source, "image.webp");
let res = await fetch("https://ezgif.com/webp-to-mp4", {
method: "POST",
body: form,
});
let html = await res.text();
const $ = cheerio.load(html);
let form2 = new FormData();
let obj = {};
$("form input[name]").each((idx, input) => {
obj[$(input).attr('name')] = $(input).attr('value');
form2.append($(input).attr('name'), $(input).attr('value'));
});
let res2 = await fetch("https://ezgif.com/webp-to-mp4/" + obj.file, {
method: "POST",
body: form2,
});
const html2 = await res2.text();
const $$ = cheerio.load(html2);
return {
status: true,
developer: 'SuryaDev',
url: new URL($$("div#output > p.outfile > video > source").attr('src'), res2.url).toString()
}
} catch (error) {
return {
status: false,
developer: 'SuryaDev',
message: String(error)
}
}
}

exports.run = {
usage: ['tovideo'],
hidden: ['tomp4'],
use: 'reply sticker',
category: 'convert',
async: async (m, { func, mecha, quoted }) => {
if (/webp/.test(quoted.mime)){
mecha.sendReact(m.chat, '🕒', m.key)
let media = await quoted.download();
let result = await webp2mp4(media);
if (!result.status) return m.reply(result.message);
await mecha.sendMessage(m.chat, {
video: {
url: result.url
},
caption: 'Convert Webp To Video'
}, {quoted: m, ephemeralExpiration: m.expiration})
} else m.reply(`Reply sticker nya dengan caption ${m.cmd}`)
},
limit: true
}