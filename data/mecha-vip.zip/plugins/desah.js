exports.run = {
usage: ['desah'],
category: 'sound',
async: async (m, { func, mecha }) => {
mecha.sendMessage(m.chat, {
audio: {
url: 'https://cdn.filestackcontent.com/C9cmOVyTSxSaYYiRjbYz'
},
mimetype: 'audio/mpeg',
ptt: true
}, {quoted: m, ephemeralExpiration: m.expiration})
},
devs: true
}