exports.run = {
    usage: ['addvipgc', 'delvipgc'],
    use: 'groupId',
    category: 'developer',
    async: async (m, {
        func,
        mecha
    }) => {
        let groupId;
        if (m.args && /^\d.*(@g\.us)$/.test(m.args[0])) {
            groupId = m.args[0];
        } else if (/^\d.*(@g\.us)$/.test(m.chat)) {
            groupId = m.chat;
        }
        if (!groupId) return m.reply(func.example(m.cmd, '120xxx@g.us'));
        const groupData = global.db.groups[groupId];
        if (!groupData) return m.reply('groupData not found.')
        if (/addvipgc/.test(m.command)) {
            if (groupData?.vip) return m.reply('The group is already VIP');
            groupData.vip = true;
            m.reply(`Successfully added “${groupData.name}“ to VIP group.`)
        } else if (/delvipgc/.test(m.command)) {
            if (!groupData?.vip) return m.reply('The group is not VIP');
            groupData.vip = false;
            m.reply(`Successfully removed “${groupData.name}“ from VIP group.`)
        }
    },
    devs: true,
    location: 'plugins/developer/addvipgc.js'
}