exports.run = {
    usage: ['blockcmd', 'unblockcmd'],
    use: 'command',
    category: 'developer',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'menu'))
        let cmd = m.text.trim().toLowerCase();
        switch (m.command) {
            case 'blockcmd':
                if (global.db.blockcmd.includes(cmd)) return m.reply(`command '${cmd}' already in the database.`)
                global.db.blockcmd.push(cmd)
                m.reply(`command '${cmd}' blocked successfully!`)
                break
            case 'unblockcmd':
                if (!global.db.blockcmd.includes(cmd)) return m.reply(`command '${cmd}' not in database.`)
                global.db.blockcmd.splice(global.db.blockcmd.indexOf(cmd), 1)
                m.reply(`command '${cmd}' has been unblocked.*`)
                break
        }
    },
    devs: true,
    location: 'plugins/developer/blockcmd.js'
}