exports.run = {
usage: 'cekpanel',
hidden: 'cekserver',
category: 'special',
async: async (m, { func, mecha, froms }) => {
const jid = (m.isDevs || m.isOwner) ? froms : m.sender;
if (!jid) return m.reply('Mention or reply chat target.');
const serverData = global.db.server[jid];
if (!serverData) return m.reply('Your data not found.')
let caption = '乂  *C H E C K - P A N E L*\n\n'
const totalServers = serverData.data.length;
if (totalServers < 1) return m.reply('Your server is empty.')
caption += `◦  *Jid* : @${jid.replace(/@.+/, '')}\n◦  *Total Server* : ${totalServers}\n*Server* :\n`;
caption += serverData.data.map((item, index) => `${index + 1}. ${item.username}\n- ID: ${item.id}\n- RAM: ${item.ram}\n- Expire: ${calculateExpireTime(item.expired)}`).join('\n\n');
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
}

function calculateExpireTime(expiredTimestamp) {
const now = Date.now();
const diff = expiredTimestamp - now;
const seconds = Math.floor((diff / 1000) % 60);
const minutes = Math.floor((diff / (1000 * 60)) % 60);
const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
const days = Math.floor(diff / (1000 * 60 * 60 * 24));
return `${days}D ${hours}H ${minutes}M ${seconds}S`;
}