const fetch = require('node-fetch');
const axios = require('axios');
const fs = require('fs');

async function uploadToGH(token, username, repo, fileName, commitMessage) {
try {
const fileContent = fs.readFileSync(fileName);

const response = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
method: 'PUT',
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
},
body: JSON.stringify({
message: commitMessage,
content: fileContent.toString('base64'),
}),
});

const jsonResponse = await response.json();
if (response.ok) {
return {
status: true,
creator: 'SuryaDev.',
result: jsonResponse.content.html_url
}
} else {
console.error('Failed to upload file:', jsonResponse.message);
return {
status: false,
creator: 'SuryaDev.',
message: jsonResponse.message
}
}
} catch (error) {
console.error('Error occurred during file upload:', error.message);
return {
status: true,
creator: 'SuryaDev.',
message: error.message
}
}
}

async function updateToGH(token, username, repo, fileName) {
try {
const fileContent = fs.readFileSync(fileName);

// Mendapatkan SHA hash dari file yang akan dihapus
const data = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
}
});

const fileData = await data.json();
const sha = fileData.sha;

const response = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
method: 'PUT',
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
},
body: JSON.stringify({
message: 'Add files via upload',
sha: sha,
content: fileContent.toString('base64'),
}),
});

const jsonResponse = await response.json();
if (response.ok) {
return {
status: true,
creator: 'SuryaDev.',
result: jsonResponse.content.html_url
}
} else {
console.error('Failed to upload file:', jsonResponse.message);
return {
status: false,
creator: 'SuryaDev.',
message: jsonResponse.message
}
}
} catch (error) {
console.error('Error occurred during file upload:', error.message);
return {
status: true,
creator: 'SuryaDev.',
message: error.message
}
}
}

async function deleteFileFromGH(token, username, repo, fileName) {
try {
// Mendapatkan SHA hash dari file yang akan dihapus
const response = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
}
});

const fileData = await response.json();
const sha = fileData.sha;

// Membuat payload untuk penghapusan file
const deletePayload = {
message: `Delete ${fileName}`,
sha: sha,
branch: 'master' // Atau ganti dengan branch yang sesuai
};

// Mengirim permintaan PUT untuk menghapus file
const deleteResponse = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
method: 'DELETE',
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
},
body: JSON.stringify(deletePayload)
});

if (deleteResponse.ok) {
return `File ${fileName} berhasil dihapus.`;
} else {
const errorData = await deleteResponse.json();
return `Gagal menghapus file: ${errorData.message}`;
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus file:', error.message);
return 'Terjadi kesalahan saat menghapus file.';
}
}


async function listFilesFromGH(token, username, repo, fileName) {
try {
const response = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/${fileName}`, {
headers: {
Authorization: `token ${token}`,
'Content-Type': 'application/json',
}
});

const jsonResponse = await response.json();
if (response.ok) {
return jsonResponse;
} else {
throw new Error(`Failed to fetch files: ${jsonResponse.message}`);
}
} catch (error) {
console.error('Error occurred during fetching file list:', error.message);
throw new Error('Terjadi kesalahan saat memuat daftar file.');
}
}

exports.run = {
usage: [
'uploadgh2',
'updategh2',
'deletefilegh2',
'listfilesgh2'
],
category: 'owner',
async: async (m, { func, mecha, calender, quoted }) => {
const username = 'username108995561';
const token = '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';
const branch = 'main';
const repo = 'User';
const filename = m.text;

switch (m.command) {
case 'uploadgh2':{
if (!m.text) return m.reply(func.example(m.cmd, 'tebakkimia.json'))
if (!/application\/javascript|application\/json|audio/.test(quoted.mime)) return m.reply('Can only upload files & audio.')
let buffer = await quoted.download();
await fs.writeFileSync(filename, buffer);
await uploadToGH(token, username, repo, filename, calender).then(response => {
if (!response.status) return m.reply(response.message)
let caption = `Successfully upload '${filename}' to github\n> ${response.result.replace('github.com', 'raw.githubusercontent.com').replace('/blob/', '/')}`;
mecha.reply(m.chat, caption, m, {expiration: m.expiration})
.then(() => fs.unlinkSync(filename))
})
}
break
case 'updategh2':{
if (!m.text) return m.reply(func.example(m.cmd, 'tebakkimia.json'))
if (!/application\/javascript|application\/json/.test(quoted.mime)) return m.reply('Can only upload files.')
let buffer = await quoted.download();
await fs.writeFileSync(filename, buffer);
await updateToGH(token, username, repo, filename).then(response => {
if (!response.status) return m.reply(response.message)
let caption = `Successfully update '${filename}' to github\n> ${response.result.replace('github.com', 'raw.githubusercontent.com').replace('/blob/', '/')}`;
mecha.reply(m.chat, caption, m, {expiration: m.expiration})
.then(() => fs.unlinkSync(filename))
})
}
break
case 'deletefilegh2':{
if (!m.text) return m.reply(func.example(m.cmd, 'tebakkimia.json'))
await deleteFileFromGH(token, username, repo, filename).then(response => {
mecha.reply(m.chat, response, m, {expiration: m.expiration})
})
}
break
case 'listfilesgh2':{
let result = await listFilesFromGH(token, username, repo, filename)
let caption = '*LIST FILES FROM GITHUB*'
result.forEach((data, index) => {
caption += `\n\n*${index + 1}.* ${data.name}`
caption += `\n- Path : ${data.path}`
caption += `\n- Size : ${func.fileSize(data.size)}`
caption += `\n- Type : ${data.type}`
caption += `\n- Url : ${data.download_url}`
})
mecha.reply(m.chat, caption, m, {expiration: m.expiration})
}
break
}
},
devs: true
}