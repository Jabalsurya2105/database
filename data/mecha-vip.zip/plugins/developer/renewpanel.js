const toMs = require('ms');

exports.run = {
usage: ['renewpanel'],
use: 'mention or reply',
category: 'developer',
async: async (m, { func, mecha }) => {
if (m.quoted && m.text) {
const [username, duration] = m.text.split(',');
if (!username) return m.reply(func.example(m.cmd, 'SuryaDev,30d'))
let jid = m.quoted.sender;
let server = global.db.server[jid];
if (!server) return m.reply('User data not found.')
let data = server.data.find(item => item.username === username)
if (!data) return m.reply(`Username tersebut tidak ditemukan di server @${jid.replace(/@.+/, '')}`)
if (data) {
data.expired += duration ? toMs(duration) : 2592000000;
let caption = `Successfully renew server for ${formatDuration(duration)}.\n
- Jid : @${jid.replace(/@.+/, '')}
- ID : ${data.id}
- Username : ${data.username}`
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else m.reply('Server tidak ditemukan.')
} else if (m.text) {
const [target, username, duration] = m.text.split(',');
if (!(target && username)) return m.reply(func.example(m.cmd, '62895415497664,SuryaDev,30d'))
let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target;
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let server = global.db.server[jid];
if (!server) return m.reply('User data not found.')
let data = server.data.find(item => item.username === username)
if (!data) return m.reply(`Username tersebut tidak ditemukan di server @${jid.replace(/@.+/, '')}`)
let renew = duration && (duration.endsWith('d') || duration.endsWith('h') || duration.endsWith('m') || duration.endsWith('s')) ? duration.replace('d', 'days').replace('h', 'hours').replace('m', 'minutes').replace('s', 'seconds') : '30 days';
if (data) {
data.expired += duration ? toMs(duration) : 2592000000;
let caption = `Successfully renew server for ${formatDuration(duration)}.\n
- Jid : @${jid.replace(/@.+/, '')}
- ID : ${data.id}
- Username : ${data.username}`
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else m.reply('Server tidak ditemukan.')
} else m.reply('Mention or Reply chat target.')
},
devs: true
}

function formatDuration (duration) {
let result = '';
if (duration) {
if (duration.endsWith('d')) result = duration.replace(/d/gi, ' days');
if (duration.endsWith('h')) result = duration.replace(/h/gi, ' hours');
if (duration.endsWith('m')) result = duration.replace(/m/gi, ' minutes');
if (duration.endsWith('s')) result = duration.replace(/s/gi, ' seconds');
} else {
result = '30 days';
}
return result;
}