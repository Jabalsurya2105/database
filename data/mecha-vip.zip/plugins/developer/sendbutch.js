exports.run = {
    usage: ['sendbutch'],
    use: 'text',
    category: 'developer',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
        const buttons = [/*{
                index: 1,
                urlButton: {
                    displayText: "website",
                    url: 'https://iyaudah-iya.vercel.app/'
                }
            },*/
            {
                index: 1,
                quickReplyButton: {
                    displayText: 'nice try',
                    id: 'https://iyaudah-iya.vercel.app/'
                }
            }
        ];
        const buttonsMessage = {
            text: m.text.trim(),
            title: '',
            footer: '𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 𝗆ᧉ𝖼𝗁α 𝖻𝗈𝗍',
            viewOnce: true,
            templateButtons: buttons,
            headerType: 2
        }
        await mecha.sendMessage(newsletter, buttonsMessage).then(() => mecha.sendReact(m.chat, '✅', m.key))
            .catch(() => mecha.sendReact(m.chat, '❌', m.key))
    },
    devs: true,
    location: 'plugins/developer/sendbutch.js'
}