const fs = require('fs')

exports.run = {
    usage: ['update'],
    hidden: ['up'],
    use: 'reply code',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'handler <reply code>'))
        if (!m.quoted) return m.reply('Reply text atau file scriptnya.');
        let key = m.text.trim().toLowerCase();
        let filepath;
        let content;
        let system = fs.readdirSync('./system');
        if (key === 'handler') filepath = './handler.js';
        if (key === 'index') filepath = './index.js';
        if (key === 'main') filepath = './main.js';
        // if (key === 'case') filepath = './case.js';
        if (key === 'config') filepath = './config.js'
        if (system.some(file => file.replace(/\.js/g, '') === key)) {
            filepath = `./system/${key}.js`;
        }
        if (key === 'youtube') filepath = './lib/youtube.js'
        if (!filepath) return m.reply('Format invalid!')
        if (!fs.existsSync(filepath)) return m.reply('file filepath not found.')
        if (/application\/javascript/.test(quoted.mime)) {
            content = await quoted.download();
        } else {
            content = m.quoted.text;
        }
        await fs.writeFileSync(filepath, content);
        await mecha.sendReact(m.chat, '✅', m.key)
    },
    devs: true,
    location: 'plugins/developer/update.js'
}