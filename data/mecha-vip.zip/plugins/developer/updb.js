const fs = require('fs');

exports.run = {
usage: ['updb'],
category: 'owner',
async: async (m, { func, mecha, errorMessage }) => {
mecha.sendReact(m.chat, '🕒', m.key)
try {
const content = JSON.parse(fs.readFileSync('./database/database.json'));
global.db = content;
await global.database.save(global.db);
if (JSON.stringify(global.db) === JSON.stringify(content)) await mecha.sendReact(m.chat, '✅', m.key)
} catch (e) {
return errorMessage(e);
}
},
devs: true
}