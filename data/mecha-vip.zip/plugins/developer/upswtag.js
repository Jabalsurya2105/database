const {
    generateWAMessage,
    STORIES_JID,
    generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['upswtag', 'upswnotag'],
    use: 'reply media',
    category: 'developer',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        try {
            const sendStatusMention = async (content, groupData, statusJidList) => {
                let success = 0,
                    failed = 0,
                    index = 0;
                const media = await generateWAMessage(STORIES_JID, content, {
                    upload: mecha.waUploadToServer,
                });
                const mentions = m.command == 'upswtag' ? statusJidList : [];
                const groupStages = itemStages(groupData);
                for (const groupId of groupStages) {
                    const additionalNodes = [{
                        tag: "meta",
                        attrs: {},
                        content: [{
                            tag: "mentioned_users",
                            attrs: {},
                            content: groupId.map((jid) => ({
                                tag: "to",
                                attrs: {
                                    jid
                                },
                                content: undefined,
                            })),
                        }],
                    }];

                    await mecha.relayMessage(STORIES_JID, media.message, {
                        messageId: media.key.id,
                        statusJidList: statusJidList, // (await Promise.all(groupId.map(async (a) => (await mecha.groupMetadata(a)).participants.map((num) => num.id)))).flat(),
                        additionalNodes,
                    });
                    for (const jid of groupId) {
                        try {
                            if (m.command === 'upswtag') await mecha.sendMessage(jid, {
                                text: 'lihat nih',
                                mentions: mentions
                            }, {
                                quoted: media,
                                ephemeralExpiration: 86400
                            });


                            await mecha.relayMessage(jid, {
                                groupStatusMentionMessage: {
                                    message: {
                                        protocolMessage: {
                                            key: media.key,
                                            type: 25,
                                        },
                                    },
                                },
                            }, {
                                userJid: mecha.user.jid,
                                additionalNodes: [{
                                    tag: "meta",
                                    attrs: {
                                        is_status_mention: "true"
                                    },
                                    content: undefined,
                                }],
                            });
                            /*const msg = await generateWAMessageFromContent(jid, {
                                statusMentionMessage: {
                                    message: {
                                        protocolMessage: {
                                            key: media.key,
                                            type: 25,
                                        },
                                    },
                                },
                            }, {});

                            await mecha.relayMessage(jid, msg.message, {
                                additionalNodes: [{
                                    tag: "meta",
                                    attrs: {
                                        is_status_mention: "true"
                                    },
                                    content: undefined,
                                }],
                            });*/
                            success++;
                        } catch (error) {
                            console.log(`Error pada: ${jid}`, error);
                            failed++;
                        }

                        index++;
                        const delay = (index % 10 === 0) ? 30000 : 3000;
                        await new Promise(resolve => setTimeout(resolve, delay));
                    }
                    await new Promise(resolve => setTimeout(resolve, 5000));
                }
                return {
                    success,
                    failed
                };
            };

            if (quoted && (/audio|video|image|conversation|extendedTextMessage/.test(quoted.mtype))) {
                if (!m.text && !/audio|video|image/.test(quoted.mime)) return m.reply(func.example(m.cmd, 'yaudah iya'));
                let groups = Object.values(await mecha.groupFetchAllParticipating()).filter(v => v.participants.find(p => p.id == mecha.user.jid) && !v.announce);
                let groupData = groups.map(x => x.id);
                let statusJidList = groups.flatMap(group => group.participants.map(v => v.id));
                // Pastikan groupData dan statusJidList tidak kosong
                if (groupData.length === 0 || statusJidList.length === 0) {
                    return m.reply('Tidak ada grup atau pengguna yang ditemukan untuk mengirim cerita.');
                }

                const caption = m.text || m.quoted && m.quoted.text || '';
                mecha.sendReact(m.chat, '🕒', m.key);
                let media;
                if (quoted.download) media = await quoted.download();
                const content = {
                    caption
                };
                // Memastikan media yang benar berdasarkan mime type
                if (/image\/(jpe?g|png)/.test(quoted.mime)) content.image = media;
                else if (/video\/mp4/.test(quoted.mime)) content.video = media;
                else if (/audio/.test(quoted.mime)) {
                    content.audio = media;
                    content.ptt = true;
                    content.mimetype = quoted.mime || 'audio/mpeg';
                } else if (/conversation|extendedTextMessage/.test(quoted.mtype)) content.text = caption;
                let {
                    success,
                    failed
                } = await sendStatusMention(content, groupData, statusJidList);
                mecha.reply(m.chat, `Berhasil mengirim cerita ke ${statusJidList.length} user di ${groupData.length} group.\nSuccess: ${success + (failed > 0 ? '\nFailed: ' + failed : '')}`, m, {
                    expiration: m.expiration
                });
            } else m.reply('Input media yang ingin dijadikan story.');
        } catch (error) {
            console.log(error);
            mecha.reply(m.chat, 'Nice Try Dev:\n' + error.message, m, {
                expiration: m.expiration
            });
        }
    },
    devs: true,
    location: 'plugins/developer/upswtag.js'
};

function itemStages(itemArray) {
    const hasil = [];

    for (let index = 0; index < itemArray.length; index += 5) {
        const stage = itemArray.slice(index, index + 5);
        hasil.push(stage);
    }

    return hasil;
}