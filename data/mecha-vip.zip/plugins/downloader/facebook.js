const axios = require("axios")

async function facebook(urls) {
const payload = new URLSearchParams()
payload.append("url", urls)
try {
const { data } = await axios.post("https://snapsave.cc/wp-json/aio-dl/video-data/", payload, {
headers: {
"content-type": "application/x-www-form-urlencoded",
"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"
}
})
return {
status: true,
author: "@dcodekemii",
media: {
title: data.title,
size: data.medias[1].formattedSize,
url: data.medias[1].url
}
}
} catch (error) {
return {
status: false,
author: "@dcodekemii",
message: error.message
}
}
}

exports.run = {
usage: ['facebook'],
hidden: ['fbdl'],
use: 'link facebook',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(`Masukkan URL!\n\nContoh: *${m.cmd} https://www.facebook.com/watch/?v=1393572814172251*`)
if (!m.args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) return m.reply(global.mess.error.url)
if (m.args[0].includes('https://l.facebook.com/l.php?u=')) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
await facebook(m.args[0]).then(async res => {
if (!res.status) return m.reply(res.message)
let caption = `*FACEBOOK DOWNLOADER*

- *Title* : ${res?.media?.title}
- *Size* : ${res?.media?.size}`
await mecha.sendMedia(m.chat, res.media.url, m, {
caption: caption,
expiration: m.expiration
});
})
},
premium: true,
limit: true
}