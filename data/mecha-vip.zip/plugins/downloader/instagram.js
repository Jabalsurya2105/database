exports.run = {
    usage: ['instagram'],
    hidden: ['igdl', 'ig'],
    use: 'link instagram',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
        const regex = /https:\/\/www\.instagram\.com\/(share\/(p|reel|tv)\/[A-Za-z0-9_-]+|reel\/[A-Za-z0-9_-]+\/?\??.*)/gi;
        if (!m.args[0].match(regex)) return m.reply(`*Link salah! Perintah ini untuk mengunduh postingan ig/reel/tv, bukan untuk highlight/story!*\n\ncontoh:\n${m.cmd} https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA==`)
        await mecha.sendReact(m.chat, '🕒', m.key)
        const result = await func.fetchJson(`https://api.siputzx.my.id/api/d/igdl?url=${m.args[0]}`);
        if (!result.status) return m.reply('Terjadi kesalahan.')
        if (result.data.length < 1) return m.reply('Data empty.');
        const images = filterDuplicates(result.data.map(x => x.url));
        for (let [index, url] of images.entries()) {
            let message = index == 0 ? m : null;
            await mecha.sendMedia(m.chat, url, m, {
                caption: images.length == 1 ? global.mess.ok : '',
                expiration: m.expiration
            })
        }
        await mecha.sendReact(m.chat, '✅', m.key)
    },
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram.js'
}

function filterDuplicates(array) {
    return [...new Set(array)];
}