const axios = require('axios');
const cheerio = require('cheerio');

String.budicanto = function (...args) {
    return String.fromCharCode(...args);
};

const decodeBase64 = (encoded) => {
    const key = 'Insb778';
    const decoder = global[String.budicanto(66, 117, 102, 102, 101, 114)].from(encoded, key.replace('Insb778', String.budicanto(98, 97, 115, 101, 54, 52)));
    return decoder.toString(String.budicanto(117, 116, 102, 45, 56));
};

const fetchInstagramMedia = async (url) => {
    try {
        const isVideo = url.includes('/reel/') || url.includes('/p/');
        const endpoint = 'https://indownloader.app/request'
        const type = isVideo ? 'video' : 'photo';

        const response = await axios.post(endpoint, `link=${encodeURIComponent(url)}&downloader=${type}`, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': 'applicatpon/json, text/javascript,*/*; q=0.01',
                'X-Requested-With': 'XMLHttpRequest',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) appleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'Referer': isVideo
                    ? 'https://indownloader.app/video-downloader'
                    : 'https://indownloader.app/download-instagram-photo'
            }
        });

        if (response.data.error === false) {
            const htmlContent = response.data.html;
            const mediaLinks = [];
            const regex = /<a\s+(?:[^>]*?\s+)?href=(["'])(.*?)\1/g;
            let match;

            while ((match = regex.exec(htmlContent)) !== null) {
                const link = match[2];
                if (link.includes('file?id=')) {
                    mediaLinks.push(link);
                }
            }

            return mediaLinks;
        } else {
            return null;
        }
    } catch (error) {
        return null;
    }
};

exports.run = {
    usage: ['instagram2'],
    hidden: ['igdl2', 'ig2'],
    use: 'link instagram',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
        const regex = /https:\/\/www\.instagram\.com\/(share\/(p|reel|tv)\/[A-Za-z0-9_-]+|reel\/[A-Za-z0-9_-]+\/?\??.*)/gi;
        if (!m.args[0].match(regex)) return m.reply(`*Link salah! Perintah ini untuk mengunduh postingan ig/reel/tv, bukan untuk highlight/story!*\n\ncontoh:\n${m.cmd} https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA==`)
        await mecha.sendReact(m.chat, '🕒', m.key)
        const result = await fetchInstagramMedia(m.args[0]);
        if (!result || result.length == 0) return m.reply('Gagal mengambil media. Coba lagi nanti.');
        for (let [index, media] of result.entries()) {
            let message = index == 0 ? m : null;
            await mecha.sendMedia(m.chat, media, m, {
                caption: result.data.length == 1 ? global.mess.ok : '',
                expiration: m.expiration
            })
        }
        await mecha.sendReact(m.chat, '✅', m.key)
    },
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram2.js'
}