exports.run = {
    usage: ['mediafire'],
    hidden: ['mfire', 'mfdl'],
    use: 'link mediafire',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
        isPrem
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://www.mediafire.com/file/a61862y1tgvfiim/ZackBotMans+(+Versi+1.0.1+).zip/file'))
        if (!m.args[0].includes('mediafire.com')) return m.reply(global.mess.error.url)
        mecha.sendReact(m.chat, '🕒', m.key)
        const result = await func.fetchJson(`https://api.siputzx.my.id/api/d/mediafire?url=${m.args[0]}`);
        if (!result.status) return m.reply('Something when wrong!')
        let data = result?.data;
        if (!data?.fileName) return m.reply('Linknya gak ada kocak!')
        let caption = `乂  *AUTO MEDIAFIRE DOWNLOADER*\n`
        caption += `\n◦ File Name: ${data.fileName}`
        caption += `\n◦ File Size: ${data.fileSize}`
        caption += `\n\n_Please wait media is being sent..._`
        mecha.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        })
        await mecha.sendMedia(m.chat, data.downloadLink, m, {
            caption: global.mess.ok,
            fileName: data.fileName,
            expiration: m.expiration
        })
    },
    limit: 3,
    location: 'plugins/downloader/mediafire.js'
}