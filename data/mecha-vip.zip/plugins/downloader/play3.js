const yts = require('yt-search'),
    axios = require('axios'),
    cheerio = require('cheerio');

async function SSVID(link) {
    try {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([\w-]{11})/;
        const match = link.match(regex);
        if (!match) {
            return "URL is invalid"
        }
        const id = match[1];

        const headers = {
            accept: "*/*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "sec-ch-ua": '"Not-A.Brand";v="99", "Chromium";v="124"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-requested-with": "XMLHttpRequest",
            Referer: "https://ssvid.net/",
            Origin: "https://ssvid.net",
            Cookie: "_ga=GA1.1.123456789.1234567890; _gid=GA1.1.987654321.0987654"
        };

        const searchResponse = await axios.post("https://ssvid.net/api/ajax/search", `query=${encodeURIComponent(link)}&vt=home`, {
            headers: headers
        });

        if (!searchResponse.data || !searchResponse.data.vid) {
            throw new Error("Tidak dapat menemukan informasi video");
        }

        const videoData = searchResponse.data;

        const mp3ConvertKey = videoData.links.mp3.mp3128.k;
        const mp3ConvertPayload = `vid=${id}&k=${encodeURIComponent(mp3ConvertKey)}`;
        const mp3ConvertResponse = await axios.post("https://ssvid.net/api/ajax/convert",
            mp3ConvertPayload, {
                headers: headers
            }
        );

        return {
            status: true,
            title: videoData.title || "Judul Tidak Diketahui",
            quality: videoData.links.mp3.mp3128.q_text,
            size: videoData.links.mp3.mp3128.size,
            downloadLink: mp3ConvertResponse.data.dlink
        };
    } catch (error) {
        console.log(error);
        return {
            status: false,
            message: error.message
        };
    }
}

async function downloadImage(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        })
        return Buffer.from(response.data, 'binary')
    } catch (error) {
        return null
    }
}

const chatId = '120363341809155691@newsletter';

exports.run = {
    usage: ['play3'],
    use: 'judul lagu',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
        users
    }) => {
        mecha.play3 = mecha.play3 || {};
        if (mecha.play3[m.sender] && !m.isPrem) return m.reply('Masih ada proses yang belum selesai BODOH.')
        if (!m.text) return m.reply(func.example(m.cmd, 'melukis senja'))
        mecha.play3[m.sender] = m.text.trim();
        mecha.sendReact(m.chat, '🕒', m.key)
        try {
            const data = (await yts(m.text)).videos[0];
            let caption = '*Y O U T U B E - P L A Y*\n'
            caption += `\n∘ Title : ${data?.title || '-'}`
            caption += `\n∘ Duration : ${data?.timestamp || data?.duration?.timestamp || '-'}`
            caption += `\n∘ Views : ${data?.views || '-'}`
            caption += `\n∘ Upload : ${data?.ago || '-'}`
            caption += `\n∘ Author : ${data?.author?.name || '-'}`
            caption += `\n∘ URL : ${data.url}`

            const result = await SSVID(data.url);
            if (!result.status) return m.reply(result.message)
            caption += `\n◦ Quality : ${result.quality}`
            caption += `\n◦ Size : ${result.size}`
            caption += `\n∘ Description: ${data?.description || '-'}`
            caption += `\n\nPlease wait, the audio file is being sent...`

            const thumbnailBuffer = await downloadImage(data.thumbnail)

                if (m.isPrem) {
                    mecha.sendMessage(m.chat, {
                        image: thumbnailBuffer,
                        caption,
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    await mecha.sendMessage(m.chat, {
                        audio: {
                            url: result.downloadLink
                        },
                        fileName: result.title + '.mp3',
                        mimetype: 'audio/mpeg',
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } else {
                    await mecha.sendMessage(chatId, {
                        audio: {
                            url: result.downloadLink
                        },
                        fileName: result.title + '.mp3',
                    mimetype: 'audio/mpeg',
                    ptt: true,
                    }).then(_ => mecha.sendMessage(chatId, {
                            text: result.title,
                            contextInfo: {
                                externalAdReply: {
                                    title: `Request from ${users.name}`,
                                    body: global.header,
                                    thumbnail: thumbnailBuffer,
                                    mediaType: 1,
                                    previewType: 'PHOTO',
                                    mediaUrl: data.url,
                                    sourceUrl: data.url,
                                    renderLargerThumbnail: false
                                }
                            }
                        })
                        .then(_ => mecha.reply(m.chat, 'Lagu berhasil dikirim\n- silahkan dengarkan disini: https://whatsapp.com/channel/0029ValXeD6C6ZvZAycpiH1z', m, {
                            expiration: m.expiration
                        })))
                }
                delete mecha.play3[m.sender];
        } catch (error) {
            delete mecha.play3[m.sender];
            mecha.sendReact(m.chat, '❌', m.key)
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/play3.js'
}