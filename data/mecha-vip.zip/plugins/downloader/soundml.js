const axios = require('axios');
const cheerio = require('cheerio');

async function MLSound(tema, query) {
try {
let res
if (tema == 'id') {
res = await axios.get("https://mobile-legends.fandom.com/wiki/" + query + "/Audio/id")
}
if (tema == 'en') {
res = await axios.get("https://mobilelegendsbuild.com/sound/" + query)
}
const html = res.data;
const $ = cheerio.load(html);
const result = [];

$('audio').each((i, el) => {
const url = $(el).attr('src');
const text = $(el).parent().parent().text().split('.ogg')[1].trim(); 
result.push({ url, text });
});

return {
status: true, 
creator: 'SuryaDev',
result: result
};
} catch (error) {
return {
status: false,
creator: 'SuryaDev',
message: 'Failed to fetch data'
};
}
}

exports.run = {
usage: ['soundml'],
use: 'hero ml',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'nana'))
mecha.sendReact(m.chat, '🕒', m.key)
let res = await MLSound('id', m.text.trim())
if (!res.status) return m.reply(res.message)
let result = res.result;
if (result.length == 0) return m.reply('Sound ML not found.')
let txt = `*SOUND MOBILE LEGENDS ${m.text.trim().toUpperCase()}*\n\nReply to this message with the number to get the sound.`;
result.forEach((hero, index) => {
txt += `\n\n*${index + 1}.* ${hero.text}`;
});
txt += '\n\n> Powered by : https://mobile-legends.fandom.com';  
const { key } = await mecha.reply(m.chat, txt, m, {expiration: m.expiration});   
mecha.soundHeroML[m.sender] = { result, key };
},
main: async (m, { func, mecha }) => {
mecha.soundHeroML = mecha.soundHeroML ? mecha.soundHeroML : {};
if (m.isBot || !(m.sender in mecha.soundHeroML)) return;
const { result, key } = mecha.soundHeroML[m.sender];
if (!m.quoted || m.quoted.id !== key.id || !m.budy) return;
mecha.sendReact(m.chat, '🕒', m.key)
const choice = m.budy.trim();
const inputNumber = Number(choice);
if (inputNumber >= 1 && inputNumber <= result.length) {
const selectedSound = result[inputNumber - 1];
try {
let audioLink = selectedSound.url;
await await mecha.sendMessage(m.chat, {
audio: {
url: audioLink
},
mimetype: 'audio/mpeg',
fileName: audioLink.split('/')[7] + '.mp3',
waveform: [100, 0, 100, 0, 100, 0, 100]
}, {quoted: m, ephemeralExpiration: m.expiration})
// Delete number list
//mecha.sendMessage(m.chat, { delete: key });
//delete mecha.soundHeroML[m.sender];
} catch (error) {
console.error('Error downloading and sending audio:', error);
await mecha.reply(m.chat, 'An error occurred while downloading and sending audio.', m, {expiration: m.expiration});
}
} else {
await mecha.reply(m.chat, 'Invalid sequence number. Please select a number corresponding to the list above.', m, {expiration: m.expiration});
}
},
premium: true,
limit: true
}