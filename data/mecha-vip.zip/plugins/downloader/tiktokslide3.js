const cheerio = require('cheerio')
const axios = require('axios')

const headers = {
    authority: "ttsave.app",
    accept: "application/json, text/plain, */*",
    origin: "https://ttsave.app",
    referer: "https://ttsave.app/en",
    "user-agent": "Postify/1.0.0",
};

const ttsave = {
    submit: async function(url, referer) {
        const headerx = {
            ...headers,
            referer
        };
        const data = {
            query: url,
            language_id: "1"
        };
        return axios.post("https://ttsave.app/download", data, {
            headers: headerx
        });
    },

    parse: function($) {
        const uniqueId = $("#unique-id").val();
        const nickname = $("h2.font-extrabold").text();
        const profilePic = $("img.rounded-full").attr("src");
        const username = $("a.font-extrabold.text-blue-400").text();
        const description = $("p.text-gray-600").text();

        const dlink = {
            nowm: $("a.w-full.text-white.font-bold").first().attr("href"),
            wm: $("a.w-full.text-white.font-bold").eq(1).attr("href"),
            audio: $("a[type='audio']").attr("href"),
            profilePic: $("a[type='profile']").attr("href"),
            cover: $("a[type='cover']").attr("href"),
        };

        const stats = {
            plays: "",
            likes: "",
            comments: "",
            shares: "",
        };

        $(".flex.flex-row.items-center.justify-center").each((index, element) => {
            const $element = $(element);
            const svgPath = $element.find("svg path").attr("d");
            const value = $element.find("span.text-gray-500").text().trim();

            if (svgPath && svgPath.startsWith("M10 18a8 8 0 100-16")) {
                stats.plays = value;
            } else if (svgPath && svgPath.startsWith("M3.172 5.172a4 4 0 015.656")) {
                stats.likes = value || "0";
            } else if (svgPath && svgPath.startsWith("M18 10c0 3.866-3.582")) {
                stats.comments = value;
            } else if (svgPath && svgPath.startsWith("M17.593 3.322c1.1.128")) {
                stats.shares = value;
            }
        });

        const songTitle = $(".flex.flex-row.items-center.justify-center.gap-1.mt-5").find("span.text-gray-500").text().trim();

        const slides = $("a[type='slide']").map((i, el) => ({
            number: i + 1,
            url: $(el).attr("href"),
        })).get();

        return {
            uniqueId,
            nickname,
            profilePic,
            username,
            description,
            dlink,
            stats,
            songTitle,
            slides,
        };
    },

    video: async function(link) {
        try {
            const response = await this.submit(link, "https://ttsave.app/en");
            const $ = cheerio.load(response.data);
            const result = this.parse($);

            if (result.slides && result.slides.length > 0) {
                return {
                    type: "slide",
                    ...result
                };
            }

            return {
                type: "video",
                ...result,
                videoInfo: {
                    nowm: result.dlink.nowm,
                    wm: result.dlink.wm,
                },
            };
        } catch (error) {
            console.error(error);
            throw error;
        }
    },
};

exports.run = {
    usage: ['tiktok6'],
    hidden: ['tiktokslide3', 'ttslide3'],
    use: 'link tiktok',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZS6tejpuf/'))
        if (!/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/.test(m.args[0])) return m.reply(global.mess.error.url)
        mecha.sendReact(m.chat, '🕒', m.key);
        try {
            const data = await ttsave.video(m.args[0]);
            const stats = data.stats;
            let caption = `\n- Title : ${data.description}`
            caption += `\n- Username : ${data.username}`
            caption += `\n- Nickname : ${data.nickname}`
            caption += `\n- Plays : ${stats.plays}`
            caption += `\n- Likes : ${stats.likes}`
            caption += `\n- Comments : ${stats.comments}`
            caption += `\n- Shares : ${stats.shares}`
            caption += `\n- Song Title : ${data.songTitle}`
            caption += `\n- Uniqueid : ${data.uniqueId}`
            if (data.type === 'slide') {
                caption = `乂  *TIKTOK - SLIDE*\n` + caption;
                caption += `\n- Total Images : ${data.slides.length}`
                caption += `\n\n_Please wait image is being sent..._`

                for (let [index, item] of data.slides.entries()) {
                    let message = index == 0 ? m : null;
                    await mecha.sendMedia(m.chat, item.url, message, {
                        caption: index == 0 ? caption : '',
                        expiration: m.expiration
                    })
                    await func.delay(1000)
                }
            } else if (data.type === 'video') {
                caption = `乂  *TIKTOK - DOWNLOADER*\n` + caption;
                caption += `\n\n_Please wait video is being sent..._`
                if (data.dlink.nowm) {
                    mecha.sendMedia(m.chat, data.dlink.nowm, m, {
                        caption: caption,
                        expiration: m.expiration
                    })
                } else {
                    mecha.sendMedia(m.chat, data.dlink.wm, m, {
                        caption: capt,
                        expiration: m.expiration
                    })
                }

            }
            mecha.sendMessage(m.chat, {
                audio: {
                    url: data.dlink.audio
                },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } catch (error) {
            console.log(error)
            mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    location: 'plugins/downloader/tiktokslide3.js'
}