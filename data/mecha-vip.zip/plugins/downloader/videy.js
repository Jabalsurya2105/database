/**
 * VIDEY UPLOADER & DOWNLOADER
 * Created by MyTeam
 * ©2024 Recoverse TEAM®
 */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

class Videy {
    /**
     * Mengunggah file video ke platform Videy.
     * @param {Buffer} buffer - Buffer yang merepresentasikan konten video.
     * @returns {Promise<string>} URL video yang diunggah.
     * @throws {Error} Jika unggahan gagal atau ID tidak ditemukan dalam respons.
     */
    static async upload(buffer) {
        try {
            const fileType = await import('file-type');
            const { ext } = await fileType.fileTypeFromBuffer(buffer);
            
            let form = new FormData();
            form.append("file", buffer, {
                filename: `video.${ext}`,
                contentType: `video/${ext}`
            });
            
            const response = await axios.post("https://videy.co/api/upload", form, {
                headers: {
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0',
                    ...form.getHeaders()
                }
            });
            
            if (response.data && response.data.id) {
                const url = `https://videy.co/v?id=${response.data.id}`;
                return url;
            } else {
                throw new Error('ID tidak ditemukan dalam JSON');
            }
        } catch (error) {
            throw error;
        }
    }

    /**
     * Mengunduh file video dari platform Videy.
     * @param {string} query - URL video dalam format: https://videy.co/v?id=ABC123.
     * @returns {Promise<Buffer>} Buffer dari file video yang diunduh.
     * @throws {Error} Jika URL tidak valid atau unduhan gagal.
     */
    static async download(query) {
        try {
            const parsedURL = new URL(query);
            const id = parsedURL.searchParams.get('id');

            if (!id) {
                throw new Error("Invalid URL. Gunakan format: https://videy.co/v?id=ABC123");
            }

            const downloadURL = `https://cdn.videy.co/${id.trim()}.mp4`;
            
            const response = await axios({
                method: 'get',
                url: downloadURL,
                responseType: 'arraybuffer'
            });

            return response.data;
        } catch (error) {
            throw error;
        }
    }
}

exports.run = {
usage: ['tovidey', 'videydl'],
use: 'parameter',
category: 'downloader',
async: async (m, { func, mecha, quoted }) => {
switch (m.command) {
case 'tovidey':{
if (!/video/.test(quoted.mime)) return m.reply(`Kirim/Reply video dengan caption ${m.cmd}`)
mecha.reply(m.chat, global.mess.wait, m, {
expiration: m.expiration,
edit: key
})
let buffer = await quoted.download()
let url = await Videy.upload(buffer);
if (!url) return mecha.sendReact(m.chat, '❌', m.key)
mecha.reply(m.chat, url, m, {
expiration: m.expiration,
edit: key
})
}
break;
case 'videydl':{
if (!m.text) return m.reply(func.example(m.cmd, 'https://videy.co/v?id=xxxxx'));
if (!/^https:\/\/videy\.co\/v\?id=.*$/.test(m.args[0])) return m.reply(global.mess.url);
mecha.sendReact(m.chat, '🕒', m.key)
let buffer = await Videy.download(m.args[0]);
mecha.sendMedia(m.chat, buffer, m, {
expiration: m.expiration
})
}
break;
}
},
limit: true
}