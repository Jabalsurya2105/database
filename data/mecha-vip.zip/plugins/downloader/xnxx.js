const cheerio = require('cheerio');
const axios = require('axios');
const fetch = require('node-fetch');

async function getFileSize(number) {
    const data = await axios.head(number);
    const filesize = data.headers["content-length"];
    if (filesize) {
        const size = parseInt(filesize);
        if (size < 1024) {
            return size + " bytes";
        } else {
            if (size < 1048576) {
                const kb = size / 1024;
                return kb.toFixed(2) + " KB";
            } else {
                if (size < 1073741824) {
                    const mb = size / 1048576;
                    return mb.toFixed(2) + " MB";
                } else {
                    const result = size / 1073741824;
                    return result.toFixed(2) + " GB";
                }
            }
        }
    } else {
        return '0';
    }
}

function xnxxsearch(query) {
    return new Promise((resolve, reject) => {
        const baseurl = 'https://www.xnxx.com'
        fetch(`${baseurl}/search/${query}/${Math.floor(Math.random() * 3) + 1}`, {
                method: 'GET'
            }).then(res => res.text())
            .then(res => {
                let $ = cheerio.load(res, {
                    xmlMode: false
                });
                let title = [];
                let url = [];
                let desc = [];
                let results = [];
                $('div.mozaique').each(function(a, b) {
                    $(b).find('div.thumb').each(function(c, d) {
                        url.push(baseurl + $(d).find('a').attr('href').replace("/THUMBNUM/", "/"))
                    })
                })
                $('div.mozaique').each(function(a, b) {
                    $(b).find('div.thumb-under').each(function(c, d) {
                        desc.push($(d).find('p.metadata').text())
                        $(d).find('a').each(function(e, f) {
                            title.push($(f).attr('title'))
                        })
                    })
                })
                for (let i = 0; i < title.length; i++) {
                    results.push({
                        title: title[i],
                        info: desc[i],
                        link: url[i]
                    })
                }
                resolve({
                    status: 200,
                    result: results
                })
            })
            .catch(err => {
                reject({
                    status: 400,
                    message: String(err)
                })
            })
    })
}

async function xnxxdl(url) {
    return new Promise((resolve, reject) => {
        fetch(`${url}`, {
                method: 'GET'
            }).then(res => res.text()).then(async (data) => {
                let $ = cheerio.load(data, {
                    xmlMode: false
                });
                const title = $("meta[property=\"og:title\"]").attr("content");
                const duration = $("span.metadata").text().replace(/\n/gi, '').split("\t\t\t\t\t")[1].split(/-/)[0];
                const quality = $('span.metadata').text().trim().split("- ")[1].replace(/\t\t\t\t\t/, '');
                const thumb = $("meta[property=\"og:image\"]").attr("content");
                const videourl = $("#video-player-bg > script:nth-child(6)").html();
                const link = (videourl.match(/html5player\.setVideoUrlHigh\('([^']+)'\)/) || [])[1];
                const size = await getFileSize(link);
                const sizeB = parseFloat(size) * (/GB/i.test(size) ? 1000000 : /MB/i.test(size) ? 1000 : /KB/i.test(size) ? 1 : /bytes?/i.test(size) ? 0.001 : /B/i.test(size) ? 0.1 : 0);
                resolve({
                    status: 200,
                    creator: 'SuryaDev',
                    result: {
                        title,
                        duration,
                        quality,
                        thumb,
                        link,
                        size,
                        sizeB
                    }
                })
            })
            .catch(err => {
                reject({
                    status: 400,
                    message: String(err)
                })
            })
    })
}

exports.run = {
    usage: ['xnxx', 'xnxxdl'],
    use: 'parameter',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        switch (m.command) {
            case 'xnxx': {
                if (!m.text) return m.reply(func.example('xnxx', 'japanese'));
                mecha.sendReact(m.chat, '🕒', m.key)
                try {
                    let data = await xnxxsearch(m.text);
                    if (data.status == 200 && data.result.length > 0) {
                        let body = '```Result from:```' + ' `' + m.text + '`'
                        let rows = []
                        for (let [index, result] of data.result.entries()) {
                            if (!result.title || !result.info || !result.link) continue
                            rows.push({
                                title: `${index + 1}. ${result.title}`,
                                description: `${result.info}`,
                                id: `${m.prefix}xnxxdl ${result.link}`
                            })
                        }
                        let sections = [{
                            title: 'PILIH XNXX DIBAWAH',
                            rows: rows
                        }]
                        let buttons = [
                            ['list', 'Click Here ⎙', sections],
                        ]
                        mecha.sendButton(m.chat, `X N X X - S E A R C H`, body, 'select the list button below.', buttons, m, {
                            userJid: m.sender,
                            expiration: m.expiration
                        })
                    } else {
                        m.reply('Tidak ada hasil yang ditemukan untuk pencarian tersebut.');
                    }
                } catch (err) {
                    console.error(err);
                    m.reply(String(err));
                }
            }
            break
            case 'xnxxdl': {
                if (!m.text) return m.reply(func.example(m.cmd, 'https://www.xnxx.com'));
                if (!func.isUrl(m.args[0]) && !m.args[0].includes('xnxx.com')) return m.reply(mess.error.url);
                mecha.sendReact(m.chat, '🕒', m.key)
                try {
                    let data = await xnxxdl(m.args[0]);
                    if (data.status != 200) return m.reply(data.message)
                    let result = data.result;
                    let caption = `- *Title:* ${result.title}
- *Duration:* ${result.duration}
- *Quality:* ${result.quality}
- *Size:* ${result.size}`
                    await mecha.sendMessage(m.chat, {
                        video: {
                            url: result.link
                        },
                        fileName: `${result.title}`,
                        mimetype: 'video/mp4',
                        caption
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    console.log(error);
                    mecha.reply(m.chat, error.message, m, {
                        expiration: m.expiration
                    });
                }
            }
            break
        }
    },
    premium: true,
    limit: 5
}