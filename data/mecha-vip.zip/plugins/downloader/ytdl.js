const axios = require('axios'),
    cheerio = require('cheerio');

async function SSVID(link) {
    try {
        const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([\w-]{11})/;
        const match = link.match(regex);
        if (!match) {
            return "Gk ada yg valid jir"
        }
        const id = match[1];

        const headers = {
            accept: "*/*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            "sec-ch-ua": '"Not-A.Brand";v="99", "Chromium";v="124"',
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-requested-with": "XMLHttpRequest",
            Referer: "https://ssvid.net/",
            Origin: "https://ssvid.net",
            Cookie: "_ga=GA1.1.123456789.1234567890; _gid=GA1.1.987654321.0987654"
        };

        const searchResponse = await axios.post(
            "https://ssvid.net/api/ajax/search",
            `query=${encodeURIComponent(link)}&vt=home`, {
                headers: headers
            }
        );

        if (!searchResponse.data || !searchResponse.data.vid) {
            throw new Error("Tidak dapat menemukan informasi video");
        }

        const videoData = searchResponse.data;

        const mp4ConvertKey =
            videoData.links.mp4.auto.k || videoData.links.mp4["18"].k;
        const mp4ConvertPayload = `vid=${id}&k=${encodeURIComponent(mp4ConvertKey)}`;
        const mp4ConvertResponse = await axios.post(
            "https://ssvid.net/api/ajax/convert",
            mp4ConvertPayload, {
                headers: headers
            }
        );

        const mp3ConvertKey = videoData.links.mp3.mp3128.k;
        const mp3ConvertPayload = `vid=${id}&k=${encodeURIComponent(mp3ConvertKey)}`;
        const mp3ConvertResponse = await axios.post(
            "https://ssvid.net/api/ajax/convert",
            mp3ConvertPayload, {
                headers: headers
            }
        );

        if (
            !mp4ConvertResponse.data ||
            mp4ConvertResponse.data.c_status !== "CONVERTED" ||
            !mp3ConvertResponse.data ||
            mp3ConvertResponse.data.c_status !== "CONVERTED"
        ) {
            throw new Error("Konversi video gagal");
        }

        return {
            status: true,
            title: videoData.title || "Judul Tidak Diketahui",
            mp4: {
                quality: videoData.links.mp4.auto.q_text ||
                    videoData.links.mp4["18"].q_text,
                size: videoData.links.mp4.auto.size ||
                    videoData.links.mp4["18"].size,
                downloadLink: mp4ConvertResponse.data.dlink
            },
            mp3: {
                quality: videoData.links.mp3.mp3128.q_text,
                size: videoData.links.mp3.mp3128.size,
                downloadLink: mp3ConvertResponse.data.dlink
            }
        };
    } catch (error) {
        console.log(error);
        return {
            status: false,
            message: error.message
        };
    }
}


exports.run = {
    usage: ['youtubedl'],
    hidden: ['ytdl'],
    use: 'link',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        try {
            if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
            if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
            mecha.sendReact(m.chat, '🕒', m.key)
            const result = await SSVID(m.args[0]);
            if (!result.status) return m.reply(result.message)
            let caption = `乂  *YOUTUBE DOWNLOADER*\n`
            caption += `\n◦ Title : ${result.title}`
            caption += '\n\n*MP4*:'
            caption += `\n◦ Quality : ${result.mp4.quality}`
            caption += `\n◦ Size : ${result.mp4.size}`
            caption += '\n\n*MP3*:'
            caption += `\n◦ Quality : ${result.mp3.quality}`
            caption += `\n◦ Size : ${result.mp3.size}`
            caption += `\n\nPlease wait, the audio & video file is being sent...`
            await mecha.reply(m.chat, caption, m, {
                expiration: m.expiration
            }).then(message => {
                mecha.sendMessage(m.chat, {
                    audio: {
                        url: result.mp3.downloadLink
                    },
                    fileName: result.title + '.mp3',
                    mimetype: 'audio/mpeg',
                }, {
                    quoted: message,
                    ephemeralExpiration: m.expiration
                })
            })

            mecha.sendMessage(m.chat, {
                video: {
                    url: result.mp4.downloadLink
                },
                caption: result.title,
                mimetype: 'video/mp4',
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } catch (error) {
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    limit: 3
}