let processedVideo = new Set();

exports.run = {
    usage: ['ytvideo'],
    hidden: ['ytv3'],
    use: 'link',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
    }) => {
        if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
        if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
        const videoUrl = m.args[0];
        if (processedVideo.has(videoUrl)) return m.reply('Masih ada proses yang belum selesai.')
        processedVideo.add(videoUrl);
        mecha.sendReact(m.chat, '🕒', m.key);
        try {
            const headers = {
                "accept": "*/*",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
                "sec-ch-ua-mobile": "?1",
                "sec-ch-ua-platform": "\"Android\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "cross-site",
                "Referer": "https://id.ytmp3.mobi/",
                "Referrer-Policy": "strict-origin-when-cross-origin"
            };

            const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {
                headers
            });
            const init = await initial.json();
            const id = videoUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
            if (!id) return m.reply('Gagal mendapatkan ID video.');

            const convertURL = init.convertURL + `&v=${id}&f=mp4&_=${Math.random()}`;
            const converts = await fetch(convertURL, {
                headers
            });
            const convert = await converts.json();

            let info = {};
            for (let i = 0; i < 5; i++) {
                await new Promise(resolve => setTimeout(resolve, 2000));
                const progressRes = await fetch(convert.progressURL, {
                    headers
                });
                info = await progressRes.json();
                if (info.progress === 3) break;
            }

            if (!info.title || !convert.downloadURL) return m.reply('Conversion failed.');
            await mecha.sendMessage(m.chat, {
                video: {
                    url: convert.downloadURL
                },
                caption: `${info.title}`,
                fileName: info.title + '.mp4',
                mimetype: 'video/mp4',
                ptv: false
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            processedVideo.delete(videoUrl);
        } catch (error) {
            processedVideo.delete(videoUrl);
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    limit: 5,
    location: 'plugins/downloader/ytvideo.js'
}