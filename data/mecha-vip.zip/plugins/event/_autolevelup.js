// Cooldown XP diperoleh untuk mencegah spam
const database = new Set();

const isGained = (userId) => {
    return database.has(userId);
}

const addCooldown = (userId) => {
    database.add(userId);
    setTimeout(() => {
        database.delete(userId);
    }, 1000 * 60); // Setiap menit
}

exports.run = {
    main: async (m, { func, mecha, groups, setting }) => {
        let user = global.db.users[m.sender];
        if (user.register && setting.autolevelup && !isGained(m.sender) && (user.level < 1000) && !m.fromMe && (m.isPc || (m.isGc && !groups.mute))) {
            if (m.isPrefix || m.fromMe) return;
            let currentLevel = user.level;
            addCooldown(m.sender);
            let currentXp = Math.floor(Math.random() * (25 - 15 + 1) + 15); // Ubah rentang XP
            let requiredXp = 10 * Math.pow(currentLevel, 2) + 50 * currentLevel + 100;
            user.exp += currentXp;
            if (user.exp >= requiredXp) { // Pastikan XP mencukupi
                user.level += 1;
                user.exp -= requiredXp; // Kurangi XP yang berlebih
                await mecha.sendReact(m.chat, '🎉', m.key);
                
            }
        }
    }
}