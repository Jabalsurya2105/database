exports.run = {
    main: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (Array.isArray(groups.blacklist) && groups.blacklist.includes(m.sender) && !m.isAdmin && !m.isPrem && !m.isOwner && !m.isDevs) {
            await mecha.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_blacklistmember.js'
}