exports.run={usage:["bomb"],hidden:["tebakbom"],category:"games",async:async(e,{func:a,mecha:t})=>{if(t.bomb=t.bomb||{},a.ceklimit(e.sender,1))return e.reply(global.mess.limit);let i=e.chat;if(i in t.bomb)return t.reply(e.chat,"*^ sesi ini belum selesai!*",t.bomb[i].msg,{expiration:e.expiration});a=["💥","✅","✅","✅","✅","✅","✅","✅","✅"].sort(()=>Math.random()-.5);let n=["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"],m=a.map((e,a)=>({emot:e,number:n[a],position:a+1,state:!1})),o=`乂  *B O M B*

Reply pesan ini dengan angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`;for(let e=0;e<m.length;e+=3)o+=m.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";o+=`
Timeout : *3 menit*
Apabila mendapat kotak yang berisi bom maka balance akan di kurangi.`;a=await t.reply(e.chat,o,t.bomb[i]?t.bomb[i].msg:e,{expiration:e.expiration});let b;t.bomb[i]={msg:a,array:m,time:setTimeout(()=>{b=m.find(e=>"💥"==e.emot),t.bomb[i]&&t.reply(e.chat,`*Waktu habis!*, Bom berada di kotak nomor ${b.number}.`,t.bomb[i].msg,{expiration:e.expiration}),delete t.bomb[i]},18e4)}},main:async(i,{func:n,mecha:m,setting:o})=>{try{let e=i.chat;let a=n.hadiah(o.hadiah),t=global.db.users[i.sender];m.bomb=m.bomb||{};var b=/^((me)?nyerah|surr?ender)$/i.test(i.budy);if(m.bomb[e]&&b&&(await m.reply(i.chat,"Menyerah",i,{expiration:i.expiration}),clearTimeout(m.bomb[e].time),delete m.bomb[e]),m.bomb[e]&&i.quoted&&i.quoted.id==m.bomb[e].msg.key.id&&!isNaN(i.budy)){var r=m.bomb[e].array.find(e=>e.position==i.budy);if(!r)return m.reply(i.chat,"Untuk membuka kotak reply pesan ini dengan angka 1 - 9",m.bomb[e]?m.bomb[e].msg:i,{expiration:i.expiration});if("💥"==r.emot){r.state=!0;var s=m.bomb[e].array,l=`乂  *B O M B*

`,l=(l=(l=(l+=s.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+(s.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n"))+(s.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n")+`Timeout : *3 menit*
`)+`*Permainan selesai!*, kotak berisi bom terbuka: (- *$${n.formatNumber(a)}* balance)`;m.reply(i.chat,l,i,{expiration:i.expiration}).then(()=>{t.balance<a?t.balance=0:t.balance-=a,clearTimeout(m.bomb[e].time),delete m.bomb[e]})}else{if(r.state)return m.reply(i.chat,`Kotak ${r.number} sudah di buka silahkan pilih kotak yang lain.`,i,{expiration:i.expiration});r.state=!0;var u,p,c=m.bomb[e].array;8<=c.filter(e=>e.state&&"💥"!=e.emot).length?(u=`乂  *B O M B*

`,u=(u=(u=(u=(u+=`Reply pesan ini dengan angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`)+c.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+c.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n")+c.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n"+`Timeout : *3 menit*
`)+`*Permainan selesai!* kotak berisi bom tidak terbuka: (+ *$${n.formatNumber(a)}* balance)`,m.reply(i.chat,u,i,{expiration:i.expiration}).then(()=>{t.balance+=a,clearTimeout(m.bomb[e].time),delete m.bomb[e]})):(p=`乂  *B O M B*

`,p=(p=(p=(p=(p+=`Reply pesan ini dengan angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`)+c.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+c.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n")+c.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n"+`Timeout : *3 menit*
`)+`Kotak berisi bom tidak terbuka : (+ *$${n.formatNumber(a)}* balance)`,m.relayMessage(i.chat,{protocolMessage:{key:m.bomb[e].msg.key,type:14,editedMessage:{conversation:p}}},{}).then(()=>{t.balance+=a}))}}}catch(e){console.log(e),m.reply(i.chat,e.message,i,{expiration:i.expiration})}return!0}};