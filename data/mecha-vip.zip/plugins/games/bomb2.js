exports.run={usage:["bomb2"],hidden:["tebakbom2"],use:"enter number",category:"games",async:async(e,{func:a,mecha:i})=>{if(i.bomb2=i.bomb2||{},a.ceklimit(e.sender,1))return e.reply(global.mess.limit);let t=e.sender;if(t in i.bomb2)return i.reply(e.chat,"*^ sesi ini belum selesai!*",i.bomb2[t].msg,{expiration:e.expiration});a=["💥","✅","✅","✅","✅","✅","✅","✅","✅"].sort(()=>Math.random()-.5);let n=["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"],m=a.map((e,a)=>({emot:e,number:n[a],position:a+1,state:!1})),o=`乂  *B O M B*

Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`;for(let e=0;e<m.length;e+=3)o+=m.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";o+=`
Timeout : *3 menit*
Apabila mendapat kotak yang berisi bom maka point akan di kurangi.`;a=await i.reply(e.chat,o,e,{expiration:e.expiration});let r;i.bomb2[t]={msg:a,array:m,time:setTimeout(()=>{r=m.find(e=>"💥"==e.emot),i.bomb2[t]&&i.reply(e.chat,`*Waktu habis!*, Bom berada di kotak nomor ${r.number}.`,i.bomb2[t].msg,{expiration:e.expiration}),delete i.bomb2[t]},18e4)}},main:async(t,{func:n,mecha:m,setting:o})=>{try{let e=t.sender;let a=n.hadiah(o.hadiah),i=global.db.users[t.sender];m.bomb2=m.bomb2||{};var r=/^((me)?nyerah|surr?ender)$/i.test(t.budy);if(m.bomb2[e]&&r&&(await m.reply(t.chat,"Menyerah",t,{expiration:t.expiration}),clearTimeout(m.bomb2[e].time),delete m.bomb2[e]),e in m.bomb2&&!isNaN(t.budy)){var b=m.bomb2[e].array.find(e=>e.position==t.budy);if(!b)return m.reply(t.chat,"Untuk membuka kotak Kirim angka 1 - 9",t,{expiration:t.expiration});if("💥"==b.emot){b.state=!0;var s=m.bomb2[e].array,l=`乂  *B O M B*

`,l=(l=(l=(l+=s.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+(s.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n"))+(s.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n")+`Timeout : *3 menit*
`)+`*Permainan selesai!*, kotak berisi bom terbuka: (- *$${n.rupiah(a)}* balance)`;m.reply(t.chat,l.trim(),t,{expiration:t.expiration}).then(()=>{i.balance<a?i.balance=0:i.balance-=a,clearTimeout(m.bomb2[e].time),delete m.bomb2[e]})}else{if(b.state)return m.reply(t.chat,`Kotak ${b.number} sudah di buka silahkan pilih kotak yang lain.`,t,{expiration:t.expiration});b.state=!0;var u,p,k=m.bomb2[e].array;8<=k.filter(e=>e.state&&"💥"!=e.emot).length?(u=`乂  *B O M B*

`,u=(u=(u=(u=(u+=`Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`)+k.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+k.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n")+k.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n"+`Timeout : *3 menit*
`)+`*Permainan selesai!* kotak berisi bom tidak terbuka: (+ *$${n.rupiah(a)}* balance)`,m.reply(t.chat,u.trim(),t,{expiration:t.expiration}).then(()=>{i.balance+=a,clearTimeout(m.bomb2[e].time),delete m.bomb2[e]})):(p=`乂  *B O M B*

`,p=(p=(p=(p=(p+=`Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :

`)+k.slice(0,3).map(e=>e.state?e.emot:e.number).join("")+"\n")+k.slice(3,6).map(e=>e.state?e.emot:e.number).join("")+"\n")+k.slice(6).map(e=>e.state?e.emot:e.number).join("")+"\n\n"+`Timeout : *3 menit*
`)+`Kotak berisi bom tidak terbuka : (+ *$${n.rupiah(a)}* balance)`,m.reply(t.chat,p.trim(),t,{expiration:t.expiration}).then(()=>{i.balance+=a}))}}}catch(e){console.log(e),m.reply(t.chat,e.message,t,{expiration:t.expiration})}return!0}};