exports.run = {
usage: ['cowboy'],
hidden: ['coboy'],
use: 'options',
category: 'games',
async: async (m, { func, mecha }) => {
mecha.cowboy = mecha.cowboy ? mecha.cowboy : {
musuh: [],
shoot: []
}
if (/left/i.test(m.text)) {
let left = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
if (mecha.cowboy.shoot.indexOf("🤠") == 0) {
mecha.cowboy.shoot = left[0]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 1) {
mecha.cowboy.shoot = left[0]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 2) {
mecha.cowboy.shoot = left[1]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 3) {
mecha.cowboy.shoot = left[2]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 4) {
mecha.cowboy.shoot = left[3]
}
let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
teks += `Your territory:\n${mecha.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${mecha.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (mecha.cowboy.musuh.indexOf("🥷") === mecha.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
} else if (/right/i.test(m.text)) {
let right = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
if (mecha.cowboy.shoot.indexOf("🤠") == 0) {
mecha.cowboy.shoot = right[1]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 1) {
mecha.cowboy.shoot = right[2]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 2) {
mecha.cowboy.shoot = right[3]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 3) {
mecha.cowboy.shoot = right[4]
} else if (mecha.cowboy.shoot.indexOf("🤠") == 4) {
mecha.cowboy.shoot = right[4]
}
let teks = `🤠 Cowboy Chacing Criminals 🥷\n\n`
teks += `Your territory:\n${mecha.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${mecha.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (mecha.cowboy.musuh.indexOf("🥷") === mecha.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
} else if (/shoot/i.test(m.text)) {
if (mecha.cowboy.shoot.indexOf("🤠") == mecha.cowboy.musuh.indexOf("🥷")) {
mecha.cowboy = {}
m.reply(`🎉 Congratulations! you succeeded in chasing the criminals! 🎉`)
}
} else {
let randMusuh = [
["🥷", "・", "・", "・", "・"],
["・", "🥷", "・", "・", "・"],
["・", "・", "🥷", "・", "・"],
["・", "・", "・", "🥷", "・"],
["・", "・", "・", "・", "🥷"]
]
let randAku = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
let musuh = func.pickRandom(randMusuh)
let aku = func.pickRandom(randAku)
mecha.cowboy.musuh = musuh
mecha.cowboy.shoot = aku
let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
teks += `Your territory:\n${mecha.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${mecha.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (mecha.cowboy.musuh.indexOf("🥷") === mecha.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
}
},
limit: true
}