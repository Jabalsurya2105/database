const {
    areJidsSameUser
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['topwin'],
    category: 'games',
    async: async (m, {
        func,
        mecha
    }) => {
        let topWins = Object.entries(global.db.users).map(([jid, v]) => {
            let totalWins = Object.values(v.game).reduce((acc, wins) => acc + wins, 0);
            return {
                jid,
                win: totalWins
            };
        });

        let sortedTopWins = topWins.sort((a, b) => b.win - a.win);
        let userIds = sortedTopWins.map(user => user.jid);
        let rank = userIds.indexOf(m.sender) + 1;

        let txt = `You are Top *${rank}* Win out of *${userIds.length}* Users\n`;
        txt += sortedTopWins.slice(0, 10).map(({
            jid,
            win
        }, i) => {
            let displayName = m.isGc && m.members.some(x => areJidsSameUser(jid, x.id)) ?
                (global.db.users[jid]?.name || mecha.getName(jid)).replaceAll('\n', '\t') :
                '@' + jid?.split('@')[0];
            return `${i + 1}. ${displayName} => ${func.formatNumber(win)} x`;
        }).join('\n');

        mecha.reply(m.chat, txt, m, {
            expiration: m.expiration
        });
    },
    location: 'plugins/games/topwin.js'
}