exports.run = {
    usage: ['addalarm', 'delalarm', 'listalarm', 'alarm'],
    hidden: 'setalarm',
    use: 'options',
    category: 'admin tools',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (!groups.alarm || !Array.isArray(groups.alarm)) {
            groups.alarm = [];
        }
        switch (m.command) {
            case 'addalarm':
            case 'setalarm': {
                // Mengambil input dari perintah
                const input = m.text.split('|');
                if (input.length < 3) {
                    return m.reply(`Format perintah salah. Contoh: ${m.prefix}addalarm name|text alarm|time|options

List Optios:
--days 0-6
--timezone Asia/Jakarta
--tagall
--open
--close

Contoh:
${m.prefix}addalarm Ucapan selamat pagi|Selamat Pagi semuanya|07:00|--timeZone Asia/Jakarta --tagall`);
                }

                const [name, textAlarm, time, ...options] = input;
                const alarmName = `${name.trim().toLowerCase()}`;
                const indexAlarm = groups.alarm.findIndex(item => item.name === alarmName);
                // if (indexAlarm === -1) return m.reply(`Alarm dengan nama “${alarmName}“ sudah ada, gunakan nama yang lain atau hapus dulu alarm tersebut.`);
                const alarmOptions = options.join(' ');
                let status = true;
                let days = null;
                let timeZone = 'Asia/Jakarta';
                let tagAll = false;
                let announce = null;

                if (alarmOptions) {
                    const optionList = alarmOptions.split('--');
                    optionList.forEach(option => {
                        const [key, value] = option.trim().split(' ');
                        const state = value && value.trim().toLowerCase();
                        switch (key) {
                            case 'status':
                                if (value && /^(on|off)$/i.test(value)) return m.reply('Format tagall salah. Harus dalam format `on/off`.')
                                status = state === 'off' ? false : true;
                                break;
                            case 'days':
                                let arrayDays = value.split(',');
                                if (arrayDays.length > 0) {
                                    // Menggunakan Set untuk menghapus angka ganda
                                    let uniqueDays = [...new Set(arrayDays.filter(day => !isNaN(day) && /^[0-6]$/.test(day)))];
                                    if (uniqueDays.length < 1) return m.reply('days harus berupa angka antara 0-6.');
                                    days = uniqueDays.slice(0, 7);
                                } else {
                                    return m.reply('value days tidak boleh kosong.');
                                }
                                break;
                            case 'timezone':
                                if (!/^(Asia\/(Jakarta|Makassar|Jayapura|Bali|Bandung|Medan|Palembang|Pontianak|Semarang)|America\/(New_York|Los_Angeles|Chicago)|Europe\/(London|Berlin|Paris|Madrid)|Asia\/(Tokyo|Seoul|Bangkok|Singapore|Kualalumpur))$/.test(value)) {
                                    return m.reply('timeZone tidak valid! contoh: Asia/Jakarta')
                                }
                                timeZone = value;
                                break;
                            case 'tagall':
                                if (value && /^(on|off)$/i.test(value)) return m.reply('Format tagall salah. Harus dalam format `on/off`.')
                                tagAll = state === 'off' ? false : true;
                                break;
                            case 'open':
                                if (value && /^(on|off)$/i.test(value)) return m.reply('Format tagall salah. Harus dalam format `on/off`.')
                                announce = state === 'off' ? null : false;
                                break
                            case 'close':
                                if (value && /^(on|off)$/i.test(value)) return m.reply('Format tagall salah. Harus dalam format `on/off`.')
                                announce = state === 'off' ? null : true;
                                break
                        }
                    });
                }

                // Validasi waktu
                const timePattern = /^([01]\d|2[0-3]):([0-5]\d)$/; // Format HH:mm
                if (!timePattern.test(time)) {
                    return m.reply('Format waktu salah. Harus dalam format HH:mm.');
                }

                // Menyimpan alarm ke dalam alarmData
                let object = {
                    name: alarmName,
                    status,
                    textAlarm,
                    time,
                    timeZone,
                    days,
                    tagAll,
                    announce,
                    createdAt: new Date()
                }
                if (indexAlarm === -1) {
                    groups.alarm.push(object)
                } else {
                    groups.alarm[indexAlarm] = object;
                }
                // Mengkonfirmasi bahwa alarm telah ditambahkan
                await m.reply(`Alarm berhasil ditambahkan:\n- Nama: ${name}\n- Pesan: ${textAlarm}\n- Waktu: ${time}\n- Opsi: ${alarmOptions || '-'}`);
            }
            break
            case 'delalarm':
                if (!groups.alarm || groups.alarm.length < 1) return m.reply('Tidak ada alarm di grup ini.')
                if (!m.text) return m.reply('Masukkan nama alarm-nya!')
                let alarmName = m.text.trim().toLowerCase();
                let alarmIndex = groups.alarm.findIndex(item => item.name === alarmName);
                if (alarmIndex === -1) return m.reply(`Alarm dengan nama “${alarmName}“ tidak ditemukan.`);
                groups.alarm.splice(alarmIndex, 1);
                m.reply(`Alarm dengan nama “${alarmName}“ berhasil dihapus.`);
                break;
            case 'listalarm':
                if (!groups.alarm || groups.alarm.length < 1) return m.reply('Tidak ada alarm di grup ini.')
                let caption = '*L I S T - A L A R M*'
                groups.alarm.forEach((item, index) => {
                    caption += `\n\n${index + 1}. ${item.name}
- Status: ${item.status ? '✅' : '❌'}
- Pesan: ${item.textAlarm}
- Waktu: ${item.time}
- timeZone: ${item.timeZone}
- Days: ${item.days ? item.days : 'setiap hari'}
- Mention: ${item.tagAll ? '✅' : '❌'}
- Announce: ${item.announce ? '✅' : '❌'}`
                })
                m.reply(caption);
                break
            case 'alarm': {
                const [index, mode] = m.args;
                if (!(index && mode)) return m.reply(func.example(m.cmd, '1 on/off'));
                if (isNaN(index)) return m.reply('index alarm harus berupa angka!');
                if (!/^(on|off)$/i.test(mode)) return m.reply('input mode on / off');
                if (!groups.alarm || groups.alarm.length < 1) return m.reply('tidak ada alarm di grup ini.')
                let alarmIndex = parseInt(index - 1);
                if (!groups.alarm[alarmIndex]) return m.reply(`alarm *${index}* tidak ditemukan.\n\n*List Alarm:*\n${groups.alarm.map((x, i) => `${i + 1}. ${x.name}`).join('\n')}`);
                let alarmName = groups.alarm[alarmIndex].name;
                let option = mode.toLowerCase();
                let status = option === 'on' ? true : false;
                if (groups.alarm[alarmIndex].status == status) return m.reply(`alarm “${alarmName}“ has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
                groups.alarm[alarmIndex].status = status ? true : false;
                m.reply(`alarm “${alarmName}“ has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`)
            }
            break
        }
    },
    group: true,
    admin: true,
    location: 'plugins/group/addalarm.js'
}

function isValidTime(time) {
    const [hours, minutes] = time.split(':').map(Number);
    return (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 60);
}