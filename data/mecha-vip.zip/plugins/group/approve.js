exports.run = {
    usage: ['approve'],
    hidden: ['accept', 'acc'],
    category: 'group',
    async: async (m, {
        func,
        mecha
    }) => {
        const [value] = m.args;
        let database = [];
        let caption = `乂  *LIST REQUEST JOIN*\n`
        caption += `\n*${m.prefix}acc 1* untuk approve peserta 1`
        caption += `\n*${m.prefix}acc all* untuk approve semua peserta`
        const data = await mecha.groupRequestParticipantsList(m.chat)
        if (data.length == 0) return m.reply('Tidak ada pending request.')
        data.forEach((item, index) => {
            database.push({
                index: index + 1,
                jid: item.jid,
                request_method: item.request_method,
                request_time: item.request_time
            })
            caption += `\n\n${index + 1}. @${item.jid.split('@')[0]}`
            caption += `\n◦  *Request method:* ${item.request_method}`
            caption += `\n◦  *Time:* ${convertMsToDate(item.request_time * 1000)}`
        })
        if (value && /^(all|semua)$/i.test(value)) {
            for (let i of data) {
                await mecha.groupRequestParticipantsUpdate(m.chat, [i.jid], 'approve')
                await func.delay(1000)
            }
            mecha.reply(m.chat, `Successfully approved ${data.length} participants.`, m, {
                expiration: m.expiration
            })
        } else if (value && database.some(x => x.index == value)) {
            let user = database[value - 1].jid;
            await mecha.groupRequestParticipantsUpdate(m.chat, [user], 'approve')
            mecha.sendReact(m.chat, '✅', m.key)
        } else await mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    group: true,
    admin: true,
    botAdmin: true
}

function convertMsToDate(ms) {
    // Membuat objek tanggal dari milidetik
    const date = new Date(ms);

    // Mengatur zona waktu Asia/Jakarta
    const options = {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };

    // Mengonversi ke string dengan format yang diinginkan
    const formattedDate = date.toLocaleString('id-ID', options);

    return formattedDate;
}