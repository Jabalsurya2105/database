exports.run = {
    usage: ['cekasalmember'],
    hidden: ['cekmember'],
    category: 'admin tools',
    async: async (m, {
        func,
        mecha
    }) => {
        function hitungJumlahPeserta(array) {
            const jumlahNegara = {};
            const countryCodes = [{
                    code: '1',
                    country: '🇺🇸 Amerika Serikat'
                },
                {
                    code: '7',
                    country: '🇷🇺 Rusia'
                },
                {
                    code: '30',
                    country: '🇬🇷 Yunani'
                },
                {
                    code: '33',
                    country: '🇫🇷 Prancis'
                },
                {
                    code: '34',
                    country: '🇪🇸 Spanyol'
                },
                {
                    code: '36',
                    country: '🇭🇺 Hongaria'
                },
                {
                    code: '39',
                    country: '🇮🇹 Italia'
                },
                {
                    code: '41',
                    country: '🇨🇭 Swiss'
                },
                {
                    code: '43',
                    country: '🇦🇹 Austria'
                },
                {
                    code: '44',
                    country: '🇬🇧 Inggris'
                },
                {
                    code: '45',
                    country: '🇩🇰 Denmark'
                },
                {
                    code: '46',
                    country: '🇸🇪 Swedia'
                },
                {
                    code: '47',
                    country: '🇳🇴 Norwegia'
                },
                {
                    code: '48',
                    country: '🇵🇱 Polandia'
                },
                {
                    code: '49',
                    country: '🇩🇪 Jerman'
                },
                {
                    code: '51',
                    country: '🇵🇪 Peru'
                },
                {
                    code: '52',
                    country: '🇲🇽 Meksiko'
                },
                {
                    code: '54',
                    country: '🇦🇷 Argentina'
                },
                {
                    code: '55',
                    country: '🇧🇷 Brasil'
                },
                {
                    code: '57',
                    country: '🇨🇴 Kolombia'
                },
                {
                    code: '58',
                    country: '🇻🇪 Venezuela'
                },
                {
                    code: '60',
                    country: '🇲🇾 Malaysia'
                },
                {
                    code: '61',
                    country: '🇦🇺 Australia'
                },
                {
                    code: '62',
                    country: '🇮🇩 Indonesia'
                },
                {
                    code: '63',
                    country: '🇵🇭 Filipina'
                },
                {
                    code: '64',
                    country: '🇳🇿 Selandia Baru'
                },
                {
                    code: '66',
                    country: '🇹🇭 Thailand'
                },
                {
                    code: '81',
                    country: '🇯🇵 Jepang'
                },
                {
                    code: '82',
                    country: '🇰🇷 Korea Selatan'
                },
                {
                    code: '86',
                    country: '🇨🇳 Tiongkok'
                },
                {
                    code: '91',
                    country: '🇮🇳 India'
                },
                {
                    code: '351',
                    country: '🇵🇹 Portugal'
                },
                {
                    code: '353',
                    country: '🇮🇪 Irlandia'
                },
                {
                    code: '358',
                    country: '🇫🇮 Finlandia'
                },
                {
                    code: '370',
                    country: '🇱🇹 Lithuania'
                },
                {
                    code: '371',
                    country: '🇱🇻 Latvia'
                },
                {
                    code: '372',
                    country: '🇪🇪 Estonia'
                },
                {
                    code: '420',
                    country: '🇨🇿 Republik Ceko'
                },
                {
                    code: '421',
                    country: '🇸🇰 Slovakia'
                },
                {
                    code: '423',
                    country: '🇱🇮 Liechtenstein'
                }
            ]
            array.forEach(kode => {
                let negara;
                let findCodes = countryCodes.find(item => kode.startsWith(item.code));
                if (findCodes) {
                    negara = findCodes.country;
                } else {
                    negara = '🏳️ Negara Lain';
                }
                if (jumlahNegara[negara]) {
                    jumlahNegara[negara]++;
                } else {
                    jumlahNegara[negara] = 1;
                }
            });

            return jumlahNegara;
        }

        const array = m.members.map(item => item.id);
        const hasil = hitungJumlahPeserta(array);
        let caption = '*A S A L - N E G A R A*'
        caption += '\n\nJumlah Anggota Grup Berdasarkan Negara:'

        for (const [negara, jumlah] of Object.entries(hasil)) {
            caption += `\n${negara}: ${jumlah}`
        }
        caption += `\n\n- Jumlah semua member: ${array.length}`
        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    location: 'plugins/group/cekmember.js',
    group: true
}