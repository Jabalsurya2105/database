exports.run = {
    usage: ['ceksewa'],
    category: 'group',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (!groups.sewa.status) return m.reply(`Grup ini tidak terdaftar dalam list sewabot. Ketik ${m.prefix}listsewa untuk info lebih lanjut`)
        let caption = `乂  *CEK SEWA GROUP*\n`
        caption += `\n◦  *Name* : ${m.groupName}`
        caption += `\n◦  *ID* : ${m.chat}`
        caption += `\n◦  *VIP* : ${groups.sewa?.vip ? '✅' : '❌'}`
        caption += `\n◦  *Expire* : ${/PERMANENT|Infinity/.test(groups.sewa.expired) ? 'PERMANENT' : func.expireTime(groups.sewa.expired)}`
        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    group: true,
    location: 'plugins/group/ceksewa.js'
}