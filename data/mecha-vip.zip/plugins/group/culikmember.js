exports.run = {
usage: ['culikmember'],
use: 'id grup',
category: 'group',
async: async (m, { func, mecha }) => {
mecha.culikmember = mecha.culikmember ? mecha.culikmember : {};
if (!m.text) return m.reply(func.example(m.cmd, '120xxxxx@g.us'))
let grupjid = m.text.trim();
if (!grupjid) return m.reply(`Input id grup yang ingin diculik\nContoh: *${m.cmd} 120xxx@g.us*`)
if (!grupjid.endsWith('@g.us')) return m.reply('Input id grup dengan benar!')
if (grupjid === m.chat) return m.reply('Gunakan id grup lain!');
if (!mecha.isgroup(grupjid)) return m.reply('Bot tidak berada didalam grup tersebut.')
try {
mecha.culikmember[m.chat] = {};
let database = mecha.culikmember[m.chat];
let move = await (await mecha.groupMetadata(grupjid));
let member = move.participants.filter(v => !v.admin).map(x => x.id);
if (member.length == 0) return m.reply('Empty data.');
if (member.length > 200) member = member.slice(member.length - 200);
await mecha.reply(m.chat, `Add *${member.length}* participants from group ${move.subject}`, m);
for (let jid of member) {
database[jid] = {
jid: jid, 
status: null 
};
await new Promise(resolve => setTimeout(resolve, 5000));
await mecha.groupParticipantsUpdate(m.chat, [jid], 'add').then(async (res) => {
for (let i of res) {
if (i.status == 403){ // di privasi
mecha.sendGroupInvite(m.chat, i.jid, {
inviteCode: i.content.content[0].attrs.code,
inviteExpiration: i.content.content[0].attrs.expiration,
groupName: m.groupName,
jpegThumbnail: await mecha.profilePictureUrl(m.chat, 'image').catch(_ => 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg'),
caption: 'Undangan untuk bergabung ke grup WhatsApp saya',
quoted: null
})
//await mecha.groupParticipantsUpdate(m.chat, [i.jid], 'remove');
database[i.jid].status = i.status;
} else if (i.status == 409){ // sudah ada di grup
//await mecha.groupParticipantsUpdate(m.chat, [i.jid], 'remove');
database[i.jid].status = i.status;
} else if (i.status == 408){ // keluar baru baru ini
database[i.jid].status = i.status;
} else if (i.status == 401){ // diblock
database[i.jid].status = i.status;
} else { // sukses
//await mecha.groupParticipantsUpdate(m.chat, [i.jid], 'remove');
database[i.jid].status = i.status;
}
}
});
}
let diblock = Object.values(database).filter(x => x.status == 401);
let diprivasi = Object.values(database).filter(x => x.status == 403);
let barukeluar = Object.values(database).filter(x => x.status == 408);
let udahada = Object.values(database).filter(x => x.status == 409);
let sukses = Object.values(database).filter(x => x.status == 200);
let txt = `Successfully add participant ${move.subject} into group ${m.groupName}`
if (sukses.length > 0) txt += '\n\nMember yang berhasil ditambahkan :\n' + sukses.map((v, i) => `> ${i + 1}. @${v.jid.split('@')[0]}`).join('\n')
if (udahada.length > 0) txt += '\n\nMember yang sudah ada di grup :\n' + udahada.map((v, i) => `> ${i + 1}. @${v.jid.split('@')[0]}`).join('\n')
if (barukeluar.length > 0) txt += '\n\nMember yang keluar baru baru ini :\n' + barukeluar.map((v, i) => `> ${i + 1}. @${v.jid.split('@')[0]}`).join('\n')
if (diprivasi.length > 0) txt += '\n\nMember yang privasi invite :\n' + diprivasi.map((v, i) => `> ${i + 1}. @${v.jid.split('@')[0]}`).join('\n')
if (diblock.length > 0) txt += '\n\nMember yang memblokir bot :\n' + diblock.map((v, i) => `> ${i + 1}. @${v.jid.split('@')[0]}`).join('\n')
await mecha.reply(m.chat, txt.trim(), m, {expiration: m.expiration});
} catch (err) {
return mecha.reply(m.chat, `Terjadi kesalahan:\n${String(err)}`, m)
}
},
owner: true,
group: true,
isBotAdmin: true
}