exports.run = {
    usage: ['deskgc'],
    hidden: ['descgc'],
    category: 'group',
    async: async (m, { mecha }) => {
        mecha.reply(m.chat, `${m.metadata?.desc || ''}`, m, {
            expiration: m.expiration
        })
    },
    group: true,
    admin: true,
    location: 'plugins/group/deskgc.js'
}