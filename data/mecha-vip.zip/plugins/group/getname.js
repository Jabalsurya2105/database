exports.run = {
    usage: ['getname', 'getpp', 'getbio'],
    use: 'mention or reply',
    category: 'group',
    async: async (m, {
        mecha,
        froms
    }) => {
        switch (m.command) {
            case 'getname':
                if (m.quoted || m.text) {
                    let name;
                    if (froms in global.db.users) {
                        name = global.db.users[froms]?.name;
                    } else {
                        name = await mecha.getName(froms);
                    }
                    mecha.reply(m.chat, name, m, {
                        expiration: m.expiration
                    })
                } else m.reply('Mention or Reply chat target.')
                break
            case 'getpp':
                if (m.quoted || m.text) {
                    if ([global.owner, ...global.devs].includes(froms) && !m.isDevs) return m.reply('Access denied.')
                    mecha.sendReact(m.chat, '🕒', m.key)
                    let pporang = await mecha.profilePictureUrl(froms, 'image').catch(_ => '')
                    if (pporang) {
                        mecha.sendMessage(m.chat, {
                            image: {
                                url: pporang
                            },
                            caption: `foto profile @${froms.split('@')[0]}`
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        })
                    } else m.reply('Gagal! profile di private.')
                } else m.reply('Mention or Reply chat target.')
                break
            case 'getbio':
                if (m.quoted || m.text) {
                    let bionya = (await mecha.fetchStatus(froms).catch(console.log('[ ERROR BIO ]')) || {}).status || 'Bio di private!'
                    mecha.reply(m.chat, bionya, m, {
                        expiration: m.expiration
                    })
                } else m.reply('Mention or Reply chat target.')
                break
        }
    },
    limit: true,
    location: 'plugins/group/getname.js'
}