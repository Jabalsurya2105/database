exports.run = {
    usage: ['listanak'],
    category: 'user',
    async: async (m, {
        mecha,
        users
    }) => {
        users.listanak = users.listanak || [];
        if (users.listanak.length == 0) return m.reply('kamu tidak punya anak, sana ngewe dulu!')
        let caption = '乂  *L I S T - A N A K*'
        caption += users.listanak.map((item, index) => `\n\n${index + 1}. kamu ${users.gender == 'Perempuan' ? 'melahirkan' : 'mendapatkan'} ${item.anak} anak dari @${item.ortu.split('@')[0]}\n- Waktu lahir: ${item.time}`)
        m.reply(caption);
    },
    group: true,
    premium: true,
    location: 'plugins/group/listanak.js'
}