exports.run = {
    usage: ['resettoxic'],
    use: 'mention or reply',
    category: 'admin tools',
    async: async (m, {
        func,
        mecha,
        froms,
        groups
    }) => {
        if (froms) {
            let member = groups.member.find(v => v.jid === froms)
            if (!member) return m.reply('Member data not found.')
            if (member.toxic == 0) return m.reply('Already reset.')
            member.toxic = 0;
            m.reply(`Success reset toxic @${froms.split('@')[0]}`)
        } else {
            let member = groups.member.filter(x => x.toxic > 0).map(v => v.toxic = 0);
            if (member.length == 0) return m.reply('Already reset.')
            m.reply(`Success reset toxic *${member.length}* member.`)
        }
    },
    group: true,
    admin: true,
    location: 'plugins/group/resettoxic.js'
}