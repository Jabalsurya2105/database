exports.run = {
    usage: ['taggc'],
    hidden: ['taggrup'],
    use: 'example',
    category: 'example',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'yaudah iya'));
        await mecha.sendMessage(m.chat, {
            text: `@${m.chat}`,
            contextInfo: {
                mentionedJid: [m.sender],
                groupMentions: [{
                    groupSubject: m.text.trim(),
                    groupJid: m.chat,
                }]
            }
        }, {
            quoted: null,
            ephemeralExpiration: m.expiration
        });
    },
    admin: true,
    location: 'plugins/group/taggc.js'
}