const {
    createCanvas,
    loadImage
} = require('canvas');
const fs = require('fs');

async function totalchatCanvas(name, profileImageUrl, groupName, totalchat) {
    const startTime = Date.now();
    const canvasWidth = 720;
    const canvasHeight = 200;
    const padding = 15;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#181818';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    const profileImage = await loadImage(profileImageUrl);
    const imageSize = 115;
    const imageX = padding + 10;
    const imageY = (canvasHeight - imageSize) / 2;
    const borderRadius = 20;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(imageX + borderRadius, imageY);
    ctx.lineTo(imageX + imageSize - borderRadius, imageY);
    ctx.arcTo(imageX + imageSize, imageY, imageX + imageSize, imageY + borderRadius, borderRadius);
    ctx.lineTo(imageX + imageSize, imageY + imageSize - borderRadius);
    ctx.arcTo(imageX + imageSize, imageY + imageSize, imageX + imageSize - borderRadius, imageY + imageSize, borderRadius);
    ctx.lineTo(imageX + borderRadius, imageY + imageSize);
    ctx.arcTo(imageX, imageY + imageSize, imageX, imageY + imageSize - borderRadius, borderRadius);
    ctx.lineTo(imageX, imageY + borderRadius);
    ctx.arcTo(imageX, imageY, imageX + borderRadius, imageY, borderRadius);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(profileImage, imageX, imageY, imageSize, imageSize);
    ctx.restore();
    const textX = imageX + imageSize + 20;
    const baseFontSize = canvasWidth / 25;
    const titleFontSize = Math.max(baseFontSize, 28);
    const subTextFontSize = titleFontSize * 0.65;
    const smallTextFontSize = titleFontSize * 0.6;
    const titlePaddingTop = 30;
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${titleFontSize}px Inter`;
    ctx.fillText(name, textX, imageY + titlePaddingTop);
    const subTextPaddingTop = 40 + subTextFontSize + 5;
    ctx.fillStyle = '#D1D5DB';
    ctx.font = `${subTextFontSize}px Inter`;
    ctx.fillText('XEoms Meta Client', textX, imageY + subTextPaddingTop);
    // ctx.fillText(groupName, textX, imageY + subTextPaddingTop);
    const chatIcon = await loadImage('https://files.catbox.moe/yzcz62.png');
    const chatIconSize = 26;
    const chatIconX = textX;
    const chatIconY = imageY + subTextPaddingTop + 15;
    ctx.drawImage(chatIcon, chatIconX, chatIconY, chatIconSize, chatIconSize);
    const chatTextPaddingTop = chatIconY + chatIconSize - 5;
    ctx.font = `${smallTextFontSize}px Inter`;
    ctx.fillText(`${totalchat} chats`, chatIconX + chatIconSize + 10, chatTextPaddingTop);
    const globeIcon = await loadImage('https://files.catbox.moe/2b9s3p.png');
    const globeSize = 36;
    const globeX = canvasWidth - globeSize - padding - 30;
    const globeY = (canvasHeight - globeSize) / 2;
    ctx.drawImage(globeIcon, globeX, globeY, globeSize, globeSize);
    const imagePath = './sampah/output.png';
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(imagePath, buffer);

    return imagePath;
}

exports.run = {
    usage: ['totalchatme'],
    hidden: ['tcm'],
    category: 'group',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        mecha.sendReact(m.chat, '🕒', m.key);
        const profile = await mecha.profilePictureUrl(m.sender, 'image');
        const memberData = groups.member.find(item => item.jid === m.sender);
        if (!memberData) return m.reply('Your data not found.')
        let imagePath = await totalchatCanvas(m.pushname, profile, groups.name, memberData.chat.rupiah())
        mecha.sendMessage(m.chat, {
            image: fs.readFileSync(imagePath),
            // caption: global.mess.ok
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    },
    group: true,
    limit: true,
    location: 'plugins/group/totalchatme.js'
}