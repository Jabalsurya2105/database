const fs = require('fs');

exports.run = {
usage: ['gtn'],
category: 'owner',
async: async (m, { func, mecha }) => {
mecha.sendReact(m.chat, '🕒', m.key)
for (let i = 0; i < 1000; i++) {
let result = await func.fetchJson('https://api.vyturex.com/country')
let country = result.country;
let link = result.link;
if (global.db.data.some(x => x.country === country && x.link === link)) continue;
global.db.data.push({
country: country,
link: link
})
await new Promise(resolve => setTimeout(resolve, 3000));
}
},
owner: true
}