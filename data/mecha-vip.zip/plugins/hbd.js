const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { randomBytes } = require('crypto');

exports.run = {
usage: ['hbd'],
use: 'text',
category: 'user',
async: async (m, { func, mecha, errorMessage }) => {
const sendEvent = async (text) => {
let [evtName, evtDesc, evtLocation, evtLink] = text.split('|');

let msg = generateWAMessageFromContent(m.chat, {
messageContextInfo: {
messageSecret: randomBytes(32)
},
eventMessage: {
"isCanceled": false,
"name": evtName || 'Powered by SuryaDev',
"description": evtDesc || global.footer,
"location": {
"degreesLatitude": 0,
"degreesLongitude": 0,
"name": "Jl.NT bersama keduanya"
},
"joinLink": "https://call.whatsapp.com/voice/OHOHlAO3421CHpDywuoVXK",
"startTime": m.messageTimestamp
}
}, {});

return await mecha.relayMessage(m.chat, msg.message, {
messageId: msg.key.id,
});;
};

const text = 'Birthday Party SuryaDev'
const eventMessage = await sendEvent(text);
return eventMessage
}
}