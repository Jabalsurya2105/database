const axios = require('axios'),
cheerio = require('cheerio'),
fs = require('fs');

const getHaditsData = async (number = '1', hal = '1') => {
return new Promise((resolve, reject) => {
axios.get(`https://ilmuislam.id/hadits/perawi/${number}/?hal=${hal}`).then(response => {
const html = response.data;
const $ = cheerio.load(html);
const haditsArray = [];

$('div.col-md-9 div.card').each((index, element) => {
let nama = $(element).find('h5.mb-0').text();
let arab = $(element).find('div[style="font-family: \'Kitab\'!important;font-size: 24px;text-align: right;"] p').text().trim();
let arti = $(element).find('div.mb-3').eq(0).find('p').text().trim();
haditsArray.push({ nama, arab, arti });
});
resolve(haditsArray);
}).catch(error => {
reject(error);
});
});
};

let hadis = 1;
let number = 250;
let list = ['abu-daud', 'ahmad', 'bukhari', 'darimi', 'ibnu-majah', 'malik', 'muslim', 'nasai', 'tirmidzi']

exports.run = {
usage: ['hds'],
hidden: ['hadist'],
use: 'name ayat',
category: 'islamic',
async: async (m, { func, mecha }) => {
if (!m.text) return;
hadis = Number(m.text);

let path = `./database/hadits/${list[hadis - 1]}.json`
let hadits = JSON.parse(fs.readFileSync(path));

for (let i = 0; i < 50; i++) {
await new Promise(resolve => setTimeout(resolve, 3000));
axios.get(`https://ilmuislam.id/hadits/perawi/${hadis}/?hal=${number}`).then(response => {
const html = response.data;
const $ = cheerio.load(html);
$('div.col-md-9 div.card').each((index, element) => {
let nama = $(element).find('h5.mb-0').text();
let arab = $(element).find('div[style="font-family: \'Kitab\'!important;font-size: 24px;text-align: right;"] p').text().trim();
let arti = $(element).find('div.mb-3').eq(0).find('p').text().trim();
hadits.push({ number: parseInt(nama.split('Nomor')[1]), arab: arab, id: arti });
});
number++;
fs.writeFileSync(path, JSON.stringify(hadits, null, 2))
}).catch(error => {
console.log(error)
return mecha.reply(devs.surya, func.jsonFormat(error), m)
})
}
m.reply(global.mess.ok)
}
}