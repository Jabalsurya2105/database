const axios = require('axios')
const cheerio = require('cheerio')

const tafsir = (query) => {
    return new Promise((resolve, reject) => {
        axios.get(`https://tafsirq.com/topik/${query}`)
            .then(({
                data
            }) => {
                const $ = cheerio.load(data)
                const hasil = []
                $('body > div:nth-child(4) > div > div.col-md-6 > div ').each(function(a, b) {
                    let result = {
                    status: 200,
                    surah: $(b).find('> div.panel-heading.panel-choco > div > div > a').text(),
                    tafsir: $(b).find('> div.panel-body.excerpt').text().trim(),
                    type: $(b).find('> div.panel-heading.panel-choco > div > div > span').text(),
                    source: $(b).find('> div.panel-heading.panel-choco > div > div > a').attr('href')
                }
                hasil.push(result)
                })
                resolve(hasil)
            })
            .catch(reject)
    })
}

exports.run = {
usage: ['tafsir'],
use: 'query',
category: 'islamic',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'zina'))
let result = await tafsir(encodeURIComponent(m.text))
let txt = '*T A F S I R - S U R A H*'
for (let i of result) {
if (i.status != 200) continue
if (!i.surah) continue
if (!i.tafsir) continue
if (!i.type) continue
if (!i.source) continue
txt += `\n\n*Surah* : ${i.surah}`
txt += `\n*Tafsir* : ${i.tafsir}`
txt += `\n*Type* : ${i.type}`
txt += `\n*Source* : ${i.source}`
}
mecha.reply(m.chat, txt, m, { expiration: m.expiration })
}
}